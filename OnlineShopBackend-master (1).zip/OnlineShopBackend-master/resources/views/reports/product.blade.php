<!DOCTYPE html>
<html>
<head>
    <title>{{ $title }}</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h1>{{ $title }}</h1>
    <table>
        <thead>
            <tr>
                <th>Product Name</th>
                @if(isset($products[0]->quantity_sold))
                    <th>Quantity Sold</th>
                @elseif(isset($products[0]->average_rating))
                    <th>Average Rating</th>
                @elseif(isset($products[0]->favorites_count))
                    <th>Favorites Count</th>
                @endif
            </tr>
        </thead>
        <tbody>
            @foreach($products as $product)
            <tr>
                <td>{{ $product->name }}</td>
                @if(isset($product->quantity_sold))
                    <td>{{ $product->quantity_sold }}</td>
                @elseif(isset($product->average_rating))
                    <td>{{ number_format($product->average_rating, 2) }}</td>
                @elseif(isset($product->favorites_count))
                    <td>{{ $product->favorites_count }}</td>
                @endif
            </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>

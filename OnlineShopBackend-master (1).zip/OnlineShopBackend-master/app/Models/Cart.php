<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cart extends Model
{
    use HasFactory;
    protected $table = 'carts';
    protected $fillable = ['user_id', 'status'];
    public $timestamps = true;

    /**
     * Relación con el usuario, un carrito pertenece a un usuario
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Relación con los artículos del carrito, un carrito puede tener muchos artículos
     */
    public function items()
    {
        return $this->hasMany(CartItem::class);
    }
}

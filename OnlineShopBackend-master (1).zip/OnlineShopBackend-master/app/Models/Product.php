<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    // Nombre de la tabla
    protected $table = 'products';

    // Campos que se pueden asignar masivamente
    protected $fillable = ['name', 'description', 'price', 'category_id'];

    public $timestamps = true;

    /**
     * Relación con la categoría, un producto pertenece a una categoría
     */
    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    /**
     * Relación con las imágenes, un producto puede tener muchas imágenes
     */
    public function images()
    {
        return $this->hasMany(ProductImage::class);
    }

    /**
     * Relación con las reseñas, un producto puede tener muchas reseñas
     */
    public function reviews()
    {
        return $this->hasMany(Review::class);
    }

    public function orderItems()
    {
        return $this->hasMany(OrderItem::class);
    }
}

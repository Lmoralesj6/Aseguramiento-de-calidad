<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Favorite;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;


class ProductController extends Controller
{


    public function create(Request $request)
    {
        try {
            $request->validate(
                [
                    'name' => 'required|string|unique:products',
                    'description' => 'required|string',
                    'price' => 'required|numeric',
                    'category_id' => 'required|exists:categories,id',
                    'images' => 'required|array|min:1|max:5',
                    'images.*' => 'required|string',
                ],
                [
                    'name.required' => 'El campo nombre es requerido.',
                    'name.string' => 'El campo nombre debe ser texto.',
                    'name.unique' => 'El nombre ya está registrado.',
                    'description.required' => 'El campo descripción es requerido.',
                    'description.string' => 'El campo descripción debe ser texto.',
                    'price.required' => 'El campo precio es requerido.',
                    'price.numeric' => 'El campo precio debe ser numérico.',
                    'category_id.required' => 'El campo categoría es requerido.',
                    'category_id.exists' => 'La categoría no existe.',
                    'images.required' => 'Se requiere al menos una imagen.',
                    'images.array' => 'Las imágenes deben estar en un arreglo.',
                    'images.min' => 'Debe proporcionar al menos una imagen.',
                    'images.max' => 'No puede subir más de 5 imágenes.',
                    'images.*.required' => 'Cada imagen es requerida y debe ser una cadena en base64.',
                ]
            );

            DB::beginTransaction();
            $product = Product::create([
                'name' => $request->name,
                'description' => $request->description,
                'price' => $request->price,
                'category_id' => $request->category_id
            ]);

            $imagePaths = [];


            foreach ($request->images as $index => $imageBase64) {
                preg_match("/^data:image\/(.*);base64/i", $imageBase64, $match);
                $imageType = $match[1];
                $image = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $imageBase64));
                $imageName = $product->id . '_' . $index . '_' . time() . '.' . $imageType;

                // Guardar imagen en la carpeta public/products
                $path = Storage::disk('public')->put($imageName, $image);

                // Generar URL pública manualmente
                $imagePaths[] = env('APP_URL') . '/products/' . $imageName;

                // Guardar la ruta de la imagen en la base de datos
                $product->images()->create(['image_path' => $imagePaths[$index]]);

                // Leer la imagen desde el disco y codificarla en base64
                $base64Image = 'data:image/' . $imageType . ';base64,' . base64_encode($image);

                // Agregar la imagen en base64 al array de respuestas
                $base64Images[] = $base64Image;
            }

            DB::commit();
            return response()->json([
                'success' => true,
                'message' => 'El producto se ha creado correctamente.',
                'images' => $base64Images,
            ], 200);
        } catch (ValidationException $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Errores de Validación.',
                'errors' => $e->errors()
            ], 422);
        }catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Ocurrió un error al crear el producto.',
            ], 422);
        }
    }


    public function update(Request $request)
    {
        try {
            $request->validate(
                [
                    'id' => 'required|exists:products,id',
                    'name' => 'required|string|unique:products,name,' . $request->id,
                    'description' => 'required|string',
                    'price' => 'required|numeric',
                    'category_id' => 'required|exists:categories,id',
                    'images' => 'nullable|array|max:5',
                    'images.*' => 'required_with:images|string',
                ],
                [
                    'id.required' => 'El campo id es requerido.',
                    'id.exists' => 'El id no existe.',
                    'name.required' => 'El campo nombre es requerido.',
                    'name.string' => 'El campo nombre debe ser texto.',
                    'name.unique' => 'El nombre ya está registrado.',
                    'description.required' => 'El campo descripción es requerido.',
                    'description.string' => 'El campo descripción debe ser texto.',
                    'price.required' => 'El campo precio es requerido.',
                    'price.numeric' => 'El campo precio debe ser numérico.',
                    'category_id.required' => 'El campo categoría es requerido.',
                    'category_id.exists' => 'La categoría no existe.',
                    'images.array' => 'Las imágenes deben estar en un arreglo.',
                    'images.max' => 'No puede subir más de 5 imágenes.',
                    'images.*.required_with' => 'Cada imagen es requerida si se proporcionan imágenes nuevas.',
                ]
            );

            DB::beginTransaction();

            // Buscar el producto
            $product = Product::find($request->id);
            $product->name = $request->name;
            $product->description = $request->description;
            $product->price = $request->price;
            $product->category_id = $request->category_id;
            $product->save();

            $imagePaths = [];
            $base64Images = [];

            // Si se proporcionan imágenes nuevas, procesarlas
            if ($request->has('images')) {
                // Eliminar las imágenes existentes si se proporcionan nuevas
                $product->images()->delete();

                foreach ($request->images as $index => $imageBase64) {
                    preg_match("/^data:image\/(.*);base64/i", $imageBase64, $match);
                    $imageType = $match[1];
                    $image = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $imageBase64));
                    $imageName = $product->id . '_' . $index . '_' . time() . '.' . $imageType;

                    // Guardar imagen en la carpeta public/products
                    $path = Storage::disk('public')->put($imageName, $image);

                    // Generar URL pública manualmente
                    $imagePaths[] = env('APP_URL') . '/products/' . $imageName;

                    // Guardar la ruta de la imagen en la base de datos
                    $product->images()->create(['image_path' => $imagePaths[$index]]);

                    // Leer la imagen desde el disco y codificarla en base64
                    $base64Image = 'data:image/' . $imageType . ';base64,' . base64_encode($image);

                    // Agregar la imagen en base64 al array de respuestas
                    $base64Images[] = $base64Image;
                }
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'El producto se ha actualizado correctamente.',
                'images' => $base64Images, // Devolver las nuevas imágenes en base64 (si las hay)
            ], 200);
        } catch (ValidationException $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Errores de Validación.',
                'errors' => $e->errors()
            ], 422);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Ocurrió un error al actualizar el producto.',
            ], 500);
        }
    }


    public function get()
    {
        try {
            // Obtener productos con sus imágenes, categoría y reseñas
            $products = Product::with(['images', 'category', 'reviews'])->get();

            // Procesar las imágenes para convertirlas a base64
            $products->each(function ($product) {
                $product->images->each(function ($image) {
                    $imagePath = public_path('products/' . basename($image->image_path));
                    if (file_exists($imagePath)) {
                        $imageData = file_get_contents($imagePath);
                        $imageType = pathinfo($imagePath, PATHINFO_EXTENSION);
                        $base64Image = 'data:image/' . $imageType . ';base64,' . base64_encode($imageData);
                        $image->base64 = $base64Image;
                    } else {
                        $image->base64 = null;
                    }
                });
            });

            return response()->json([
                'success' => true,
                'message' => 'Productos obtenidos correctamente.',
                'products' => $products
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Ocurrió un error al obtener los productos.',
                'error' => $e->getMessage()
            ], 500);
        }
    }


    public function delete(Request $request)
    {
        try{
            $request->validate(
                [
                    'id' => 'required|exists:products,id'
                ],
                [
                    'id.required' => 'El campo id es requerido.',
                    'id.exists' => 'El id no existe.'
                ]
            );

            $product = Product::find($request->id);
            $product->delete();

            return response()->json([
                'success' => true,
                'message' => 'El producto se ha eliminado correctamente.'
            ], 200);
        }catch(ValidationException $e){
            return response()->json([
                'success' => false,
                'message' => 'Errores de Validación.',
                'errors' => $e->errors()
            ], 422);
        }
    }

    public function add_fav(Request $request)
    {
        try{
            $request->validate(
                [
                    'user_id' => 'required|exists:users,id',
                    'product_id' => 'required|exists:products,id',
                ],
                [
                    'user_id.required' => 'El campo id de usuario es requerido.',
                    'user_id.exists' => 'El id de usuario no existe.',
                    'product_id.required' => 'El campo id de producto es requerido.',
                    'product_id.exists' => 'El id de producto no existe.',
                ]
            );

            $fav = Favorite::create([
                'user_id' => $request->user_id,
                'product_id' => $request->product_id
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Se ha añadido a favoritos correctamente.'
            ], 200);
        }catch(ValidationException $e){
            return response()->json([
                'success' => false,
                'message' => 'Errores de Validación.',
                'errors' => $e->errors()
            ], 422);
        }
    }

    public function get_favs(Request $request)
    {
        try {
            $request->validate(
                [
                    'user_id' => 'required|exists:users,id',
                ],
                [
                    'user_id.required' => 'El campo id de usuario es requerido.',
                    'user_id.exists' => 'El id de usuario no existe.',
                ]
            );

            $favs = Favorite::where('user_id', $request->user_id)->get();

            // Obtener productos con sus imágenes, categoría y reseñas
            $products = Product::whereIn('id', $favs->pluck('product_id'))
                ->with(['images', 'category', 'reviews'])
                ->get();

            // Procesar las imágenes para convertirlas a base64
            $products->each(function ($product) {
                $product->images->each(function ($image) {
                    $imagePath = public_path('products/' . basename($image->image_path));
                    if (file_exists($imagePath)) {
                        $imageData = file_get_contents($imagePath);
                        $imageType = pathinfo($imagePath, PATHINFO_EXTENSION);
                        $base64Image = 'data:image/' . $imageType . ';base64,' . base64_encode($imageData);
                        $image->base64 = $base64Image;
                    } else {
                        $image->base64 = null;
                    }
                });
            });

            return response()->json([
                'success' => true,
                'message' => 'Productos favoritos obtenidos correctamente.',
                'products' => $products
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Ocurrió un error al obtener los productos favoritos.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function remove_fav(Request $request)
    {
        try {
            $request->validate(
                [
                    'user_id' => 'required|exists:users,id',
                    'product_id' => 'required|exists:products,id',
                ],
                [
                    'user_id.required' => 'El campo id de usuario es requerido.',
                    'user_id.exists' => 'El id de usuario no existe.',
                    'product_id.required' => 'El campo id de producto es requerido.',
                    'product_id.exists' => 'El id de producto no existe.',
                ]
            );

            $fav = Favorite::where('user_id', $request->user_id)
                ->where('product_id', $request->product_id)
                ->first();

            if ($fav) {
                $fav->delete();
                return response()->json([
                    'success' => true,
                    'message' => 'Se ha eliminado de favoritos correctamente.'
                ], 200);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'El producto no está en la lista de favoritos.'
                ], 422);
            }
        } catch (ValidationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Errores de Validación.',
                'errors' => $e->errors()
            ], 422);
        }
    }
}

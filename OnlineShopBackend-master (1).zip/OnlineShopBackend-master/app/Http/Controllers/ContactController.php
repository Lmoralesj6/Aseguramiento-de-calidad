<?php

namespace App\Http\Controllers;

use App\Models\Contact;
use Illuminate\Http\Request;
use App\Mail\ContactConfirmation;
use Illuminate\Support\Facades\Mail;
use Illuminate\Validation\ValidationException;

class ContactController extends Controller
{
    public function store(Request $request)
    {
        try {
            $request->validate([
                'name' => 'required|string|max:255',
                'email' => 'required|string|email|max:255',
                'message' => 'required|string|max:1000',
            ],
            [
                'name.required' => 'El campo nombre es requerido.',
                'name.string' => 'El campo nombre debe ser texto.',
                'name.max' => 'El campo nombre no puede ser mayor de 255 caracteres.',
                'email.required' => 'El campo correo es requerido.',
                'email.string' => 'El campo correo debe ser texto.',
                'email.email' => 'El campo correo debe ser una dirección de correo válida.',
                'email.max' => 'El campo correo no puede ser mayor de 255 caracteres.',
                'message.required' => 'El campo mensaje es requerido.',
                'message.string' => 'El campo mensaje debe ser texto.',
                'message.max' => 'El campo mensaje no puede ser mayor de 1000 caracteres.',
            ]);

            $contact = Contact::create([
                'name' => $request->name,
                'email' => $request->email,
                'message' => $request->message
            ]);

             // Enviar correo de confirmación
            Mail::to($request->email)->send(new ContactConfirmation($contact));

            return response()->json([
                'success' => true,
                'message' => 'Contacto creado correctamente.',
                'contact' => $contact,
            ], 200);
        } catch (ValidationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Errores de validación.',
                'errors' => $e->errors(),
            ], 422);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Ocurrió un error al almacenar el contacto.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function get()
    {
        $contacts = Contact::all();

        return response()->json([
            'success' => true,
            'contacts' => $contacts,
        ], 200);
    }
}

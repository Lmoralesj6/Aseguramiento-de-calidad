<?php

namespace App\Http\Controllers;

use PDF;
use App\Models\Product;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class ReportingController extends Controller
{
    // Generar el reporte de productos más vendidos
    public function bestSellingProductsReport()
    {
        $bestSellingProducts = $this->getBestSellingProducts();
        $bestSellingProducts = collect($bestSellingProducts);

        if ($bestSellingProducts->isEmpty()) {
            return response()->json(['message' => 'No se encontraron productos más vendidos'], 404);
        }

        $pdf = $this->generateProductReport($bestSellingProducts, 'Productos Más Vendidos');

        return response($pdf, 200)
            ->header('Content-Type', 'application/pdf')
            ->header('Content-Disposition', 'attachment; filename="best_selling_products_report.pdf"');
    }

    // Generar el reporte de productos con el mejor ranking
    public function highestRankingProductsReport()
    {
        $highestRankingProducts = $this->getHighestRankingProducts();
        $highestRankingProducts = collect($highestRankingProducts);

        if ($highestRankingProducts->isEmpty()) {
            return response()->json(['message' => 'No se encontraron productos con mejor ranking'], 404);
        }

        $pdf = $this->generateProductReport($highestRankingProducts, 'Productos con Mejor Ranking');

        return response($pdf, 200)
            ->header('Content-Type', 'application/pdf')
            ->header('Content-Disposition', 'attachment; filename="highest_ranking_products_report.pdf"');
    }

    // Generar el reporte de productos más añadidos a favoritos
    public function mostFavoritedProductsReport()
    {
        $mostFavoritedProducts = $this->getMostFavoritedProducts();
        $mostFavoritedProducts = collect($mostFavoritedProducts);

        if ($mostFavoritedProducts->isEmpty()) {
            return response()->json(['message' => 'No se encontraron productos favoritos'], 404);
        }

        $pdf = $this->generateProductReport($mostFavoritedProducts, 'Productos Más Favoritos');

        return response($pdf, 200)
            ->header('Content-Type', 'application/pdf')
            ->header('Content-Disposition', 'attachment; filename="most_favorited_products_report.pdf"');
    }

    // Consulta para obtener los productos más vendidos
    private function getBestSellingProducts()
    {
        try {
            $products = Product::join('order_items', 'products.id', '=', 'order_items.product_id')
                ->join('orders', 'order_items.order_id', '=', 'orders.id')
                ->select('products.name', DB::raw('SUM(order_items.quantity) as quantity_sold'))
                /* ->where('orders.status', 'completed') */ // Filtrar por pedidos completados si es necesario
                ->groupBy('products.id', 'products.name')
                ->orderBy('quantity_sold', 'desc')
                ->get();

            return $products;
        } catch (\Exception $e) {
            logger($e->getMessage());
            return [];
        }
    }

    // Consulta para obtener los productos con mejor ranking
    private function getHighestRankingProducts()
    {
        return DB::table('products as p')
            ->join('reviews as r', 'p.id', '=', 'r.product_id')
            ->select('p.name', DB::raw('AVG(r.rating) as average_rating'))
            ->groupBy('p.id', 'p.name')
            ->orderBy('average_rating', 'desc')
            ->get();
    }

    // Consulta para obtener los productos más añadidos a favoritos
    private function getMostFavoritedProducts()
    {
        return DB::table('products as p')
            ->join('favorites as f', 'p.id', '=', 'f.product_id')
            ->select('p.name', DB::raw('COUNT(f.id) as favorites_count'))
            ->groupBy('p.id', 'p.name')
            ->orderBy('favorites_count', 'desc')
            ->get();
    }

    // Generar el reporte PDF
    private function generateProductReport($products, $title)
    {
        $pdf = PDF::loadView('reports.product', ['products' => $products, 'title' => $title]);
        return $pdf->output();
    }

    public function getProductChartData()
    {
        try {
            // Datos de productos más vendidos
            $bestSellingProducts = $this->getBestSellingProducts();

            // Datos de productos mejor calificados
            $highestRankingProducts = $this->getHighestRankingProducts();

            // Datos de productos más añadidos a favoritos
            $mostFavoritedProducts = $this->getMostFavoritedProducts();

            // Estructura de respuesta
            return response()->json([
                'bestSellingProducts' => $bestSellingProducts,
                'highestRankingProducts' => $highestRankingProducts,
                'mostFavoritedProducts' => $mostFavoritedProducts,
            ], 200);
        } catch (\Exception $e) {
            logger($e->getMessage());
            return response()->json(['message' => 'Error al obtener los datos para las gráficas'], 500);
        }
    }

}

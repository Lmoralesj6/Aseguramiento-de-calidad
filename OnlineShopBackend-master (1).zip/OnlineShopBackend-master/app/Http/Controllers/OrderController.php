<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Product;
use App\Models\OrderItem;
use Illuminate\Http\Request;
use App\Mail\OrderConfirmation;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Validation\ValidationException;

class OrderController extends Controller
{
    public function store(Request $request)
    {
        try {
            $request->validate([
                'items' => 'required|array|min:1',
                'items.*.product_id' => 'required|exists:products,id',
                'items.*.quantity' => 'required|integer|min:1',
                'address.department' => 'required|string',
                'address.municipality' => 'required|string',
                'address.exact_address' => 'required|string',
                'address.references' => 'required|string',
            ], [
                'items.required' => 'Debe agregar al menos un producto al pedido.',
                'items.*.product_id.required' => 'El ID del producto es requerido.',
                'items.*.product_id.exists' => 'El producto no existe.',
                'items.*.quantity.required' => 'La cantidad es requerida.',
                'items.*.quantity.integer' => 'La cantidad debe ser un número entero.',
                'items.*.quantity.min' => 'La cantidad mínima es 1.',
                'address.department.required' => 'El campo departamento es requerido.',
                'address.department.string' => 'El campo departamento debe ser texto.',
                'address.municipality.required' => 'El campo municipio es requerido.',
                'address.municipality.string' => 'El campo municipio debe ser texto.',
                'address.exact_address.required' => 'El campo dirección exacta es requerido.',
                'address.exact_address.string' => 'El campo dirección exacta debe ser texto.',
                'address.references.required' => 'El campo referencias es requerido.',
                'address.references.string' => 'El campo referencias debe ser texto.',
            ]);

            DB::beginTransaction();

            $user = $request->user();
            $totalPrice = 0;

            // Crear el pedido
            $order = Order::create([
                'user_id' => $user->id,
                'total' => 0, // Se actualizará después
                'status' => 'pending',
                'department' => $request->input('address.department'),
                'municipality' => $request->input('address.municipality'),
                'exact_address' => $request->input('address.exact_address'),
                'references' => $request->input('address.references'),
            ]);

            // Agregar artículos al pedido
            foreach ($request->items as $item) {
                $product = Product::find($item['product_id']);
                $price = $product->price * $item['quantity'];
                $totalPrice += $price;

                OrderItem::create([
                    'order_id' => $order->id,
                    'product_id' => $product->id,
                    'quantity' => $item['quantity'],
                    'price' => $price,
                ]);
            }

            // Actualizar el precio total del pedido
            $order->update(['total' => $totalPrice]);

            // Enviar correo de confirmación
            Mail::to($user->email)->send(new OrderConfirmation($order));

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Pedido creado correctamente y correo de confirmación enviado.',
                'order' => $order,
            ], 200);
        } catch (ValidationException $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Errores de validación.',
                'errors' => $e->errors(),
            ], 422);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Ocurrió un error al crear el pedido.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function getAll(Request $request)
    {
        try {
            return response()->json([
                'success' => true,
                'orders' => Order::all(),
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Ocurrió un error al obtener los pedidos.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function get(Request $request)
    {
        try {
            $orders = Order::where('user_id', $request->user()->id)->with('items.product')->get();
            if ($orders->isEmpty()) {
                return response()->json([
                    'success' => false,
                    'message' => 'No se encontraron pedidos.',
                ], 404);
            }else{
                return response()->json([
                    'success' => true,
                    'orders' => $orders,
                ], 200);
            }
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Ocurrió un error al obtener los pedidos.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function updateStatus(Request $request)
    {
        try {
            $request->validate([
                'id' => 'required|exists:orders,id',
                'status' => 'required|string',
            ], [
                'id.required' => 'El ID de la orden es requerido.',
                'id.exists' => 'La orden no existe.',
                'status.required' => 'El estado de la orden es requerido.',
                'status.string' => 'El estado de la orden debe ser texto.',
            ]);

            $order = Order::findOrFail($request->id);
            $status = $request->status;

            $order->update(['status' => $status]);

            return response()->json([
                'success' => true,
                'message' => 'Estado de la orden actualizado correctamente.',
                'order' => $order,
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Ocurrió un error al actualizar el estado de la orden.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

}

<?php

namespace App\Http\Controllers;

use App\Models\Cart;
use App\Models\CartItem;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class CartController extends Controller
{
    public function create(Request $request)
    {
        try {
            $request->validate([
                'user_id' => 'required|exists:users,id',
                'items' => 'required|array',
                'items.*.id' => 'required|exists:products,id',
                'items.*.cantidad' => 'required|integer|min:1',
            ], [
                'user_id.required' => 'El campo usuario es requerido.',
                'user_id.exists' => 'El usuario no existe.',
                'items.required' => 'Debe enviar al menos un producto.',
                'items.*.id.required' => 'El ID del producto es requerido.',
                'items.*.id.exists' => 'El producto no existe.',
                'items.*.cantidad.required' => 'La cantidad es requerida.',
                'items.*.cantidad.integer' => 'La cantidad debe ser un número entero.',
                'items.*.cantidad.min' => 'La cantidad debe ser al menos 1.',
            ]);

            DB::beginTransaction();

            // Crear el carrito
            $cart = Cart::create([
                'user_id' => $request->user_id,
                'status' => 'pending',
            ]);

            // Crear los ítems del carrito
            foreach ($request->items as $item) {
                $product = Product::find($item['id']);

                CartItem::create([
                    'cart_id' => $cart->id,
                    'product_id' => $product->id,
                    'quantity' => $item['cantidad'],
                ]);
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Carrito creado correctamente.',
                'cart' => $cart->load('items'), // Carga los ítems asociados al carrito
            ], 200);
        } catch (ValidationException $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Errores de Validación.',
                'errors' => $e->errors(),
            ], 422);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Error al crear el carrito.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function addItem(Request $request)
    {
        try {
            $request->validate([
                'product_id' => 'required|exists:products,id',
                'quantity' => 'required|integer|min:1',
                'cart_id' => 'required|exists:carts,id',
            ], [
                'product_id.required' => 'El campo producto es requerido.',
                'product_id.exists' => 'El producto no existe.',
                'quantity.required' => 'El campo cantidad es requerido.',
                'quantity.integer' => 'La cantidad debe ser un número entero.',
                'quantity.min' => 'La cantidad debe ser al menos 1.',
                'cart_id.required' => 'El campo carrito es requerido.',
                'cart_id.exists' => 'El carrito no existe.',
            ]);

            DB::beginTransaction();

            // Verificar si el artículo ya está en el carrito
            $cartItem = CartItem::where('cart_id', $request->cart_id)
                ->where('product_id', $request->product_id)
                ->first();

            if ($cartItem) {
                // Si el artículo ya está en el carrito, incrementar la cantidad
                $cartItem->quantity += $request->quantity;
                $cartItem->save();
            } else {
                // Si el artículo no está en el carrito, agregarlo
                CartItem::create([
                    'cart_id' => $request->cart_id,
                    'product_id' => $request->product_id,
                    'quantity' => $request->quantity,
                ]);
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Artículo agregado al carrito correctamente.',
            ], 200);
        } catch (ValidationException $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Errores de Validación.',
                'errors' => $e->errors(),
            ], 422);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Error al agregar el artículo al carrito.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function getCartItems(Request $request)
    {
        try {
            $cart = Cart::with('items.product')->findOrFail($request->cart_id);

            return response()->json([
                'success' => true,
                'cart' => $cart,
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error al obtener los artículos del carrito.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function updateCartStatus(Request $request)
    {
        try {
            $request->validate([
                'status' => 'required|string|in:pending,completed,cancelled',
                'cart_id' => 'required|exists:carts,id',
            ], [
                'status.required' => 'El campo estado es requerido.',
                'status.in' => 'El estado debe ser uno de los siguientes: pending, completed, cancelled.',
                'cart_id.required' => 'El campo carrito es requerido.',
                'cart_id.exists' => 'El carrito no existe.',
            ]);

            DB::beginTransaction();

            $cart = Cart::findOrFail($request->cart_id);
            $cart->update([
                'status' => $request->status,
            ]);

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Carrito actualizado correctamente.',
                'cart' => $cart,
            ], 200);
        } catch (ValidationException $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Errores de Validación.',
                'errors' => $e->errors(),
            ], 422);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Error al actualizar el carrito.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function deleteCartItem(Request $request)
    {
        try {

            $request->validate([
                'cart_item_id' => 'required|exists:cart_items,id',
            ], [
                'cart_item_id.required' => 'El campo artículo del carrito es requerido.',
                'cart_item_id.exists' => 'El artículo del carrito no existe.',
            ]);

            DB::beginTransaction();

            $cartItem = CartItem::findOrFail($request->cart_item_id);
            $cartItem->delete();

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Artículo eliminado del carrito correctamente.',
            ], 200);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Error al eliminar el artículo del carrito.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }



    public function getCart(Request $request)
    {
        try {
            $request->validate([
                'user_id' => 'required|exists:users,id',
            ], [
                'user_id.required' => 'El campo usuario es requerido.',
                'user_id.exists' => 'El usuario no existe.',
            ]);

            $carts = Cart::where('user_id', $request->user_id)
                ->with('items.product.images') // Cargar los ítems y los productos asociados
                ->get();

            if ($carts->isEmpty()) {
                return response()->json([
                    'success' => false,
                    'message' => 'No se encontraron carritos para el usuario especificado.',
                ], 404);
            }

            return response()->json([
                'success' => true,
                'message' => 'Carritos encontrados correctamente.',
                'carts' => $carts,
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error al obtener los carritos.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function delete(Request $request)
    {
        try {
            $request->validate([
                'cart_id' => 'required|exists:carts,id',
            ], [
                'cart_id.required' => 'El campo carrito es requerido.',
                'cart_id.exists' => 'El carrito no existe.',
            ]);

            DB::beginTransaction();

            $cart = Cart::findOrFail($request->cart_id);
            $cart->items()->delete(); // Elimina los ítems asociados antes de eliminar el carrito
            $cart->delete();

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Carrito eliminado correctamente.',
            ], 200);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Error al eliminar el carrito.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
}


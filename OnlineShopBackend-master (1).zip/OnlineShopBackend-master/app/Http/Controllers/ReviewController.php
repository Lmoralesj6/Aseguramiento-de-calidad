<?php

namespace App\Http\Controllers;

use App\Models\Review;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class ReviewController extends Controller
{
    public function store(Request $request)
    {
        try {
            $request->validate([
                'product_id' => 'required|exists:products,id',
                'rating' => 'required|integer|min:1|max:5',
                'comment' => 'required|string|max:1000',
            ], [
                'product_id.required' => 'El campo producto es requerido.',
                'product_id.exists' => 'El producto no existe.',
                'rating.required' => 'El campo calificación es requerido.',
                'rating.integer' => 'La calificación debe ser un número entero.',
                'rating.min' => 'La calificación mínima es 1.',
                'rating.max' => 'La calificación máxima es 5.',
                'comment.required' => 'El campo comentario es requerido.',
                'comment.string' => 'El comentario debe ser texto.',
                'comment.max' => 'El comentario no puede exceder los 1000 caracteres.',
            ]);

            $review = Review::create([
                'product_id' => $request->product_id,
                'username' => $request->user()->name,
                'user_id' => $request->user()->id,
                'rating' => $request->rating,
                'comment' => $request->comment,
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Reseña creada correctamente.',
                'review' => $review,
            ], 200);
        } catch (ValidationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Errores de validación.',
                'errors' => $e->errors(),
            ], 422);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Ocurrió un error al crear la reseña.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
}

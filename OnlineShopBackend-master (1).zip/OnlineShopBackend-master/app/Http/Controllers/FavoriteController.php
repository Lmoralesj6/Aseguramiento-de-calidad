<?php

namespace App\Http\Controllers;

use App\Models\Contact;
use Illuminate\Http\Request;
use App\Mail\ContactConfirmation;
use App\Models\Favorite;
use Illuminate\Support\Facades\Mail;
use Illuminate\Validation\ValidationException;

class FavoriteController extends Controller
{
    public function store(Request $request)
    {
        try {
            $request->validate([
                'user_id' => 'required|integer',
                'product_id' => 'required|integer',
            ],
            [
                'user_id.required' => 'El campo nombre es requerido.',
                'user_id.integer' => 'El campo nombre debe ser un entero.',
                'product_id.required' => 'El campo correo es requerido.',
                'product_id.integer' => 'El campo product_id debe ser entero.',
            ]);

            $favorite = Favorite::create([
                'user_id' => $request->user_id,
                'product_id'=> $request->product_id
            ]);



            return response()->json([
                'success' => true,
                'message' => 'Producto agregado a favoritos',
            ], 200);
        } catch (ValidationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Errores de validación.',
                'errors' => $e->errors(),
            ], 422);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Ocurrió un error al agregar el producto a favoritos',
                'error' => $e->getMessage(),
            ], 500);
        }
    }


    public function get(){
        try {
            $products = Favorite::with(['images', 'category', 'reviews'])->get();

            // Procesar las imágenes para convertirlas a base64
            $products->each(function ($product) {
                $product->images->each(function ($image) {
                    $imagePath = public_path('products/' . basename($image->image_path));
                    if (file_exists($imagePath)) {
                        $imageData = file_get_contents($imagePath);
                        $imageType = pathinfo($imagePath, PATHINFO_EXTENSION);
                        $base64Image = 'data:image/' . $imageType . ';base64,' . base64_encode($imageData);
                        $image->base64 = $base64Image;
                    } else {
                        $image->base64 = null;
                    }
                });
            });

            return response()->json([
                'success' => true,
                'message' => 'Productos obtenidos correctamente.',
                'products' => $products
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Ocurrió un error al obtener los productos.',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\Role;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class RoleController extends Controller
{
    public function createRole(Request $request)
    {
        try{
            $request->validate(
                [
                    'name' => 'required|string|unique:roles'
                ],
                [
                    'name.required' => 'El campo nombre es requerido.',
                    'name.string' => 'El campo nombre debe ser texto.',
                    'name.unique' => 'El nombre ya está registrado.'
                ]
            );

            $role = Role::create(['name' => $request->name]);

            return response()->json([
                'success' => true,
                'message' => 'El rol se ha creado correctamente.'
            ], 200);
        }catch(ValidationException $e){
            return response()->json([
                'success' => false,
                'message' => 'Errores de Validación.',
                'errors' => $e->errors()
            ], 422);
        }
    }

    public function update(Request $request)
    {
        try{
            $request->validate(
                [
                    'id' => 'required|exists:roles,id',
                    'name' => 'required|string|unique:roles,name,' . $request->id
                ],
                [
                    'id.required' => 'El campo id es requerido.',
                    'id.exists' => 'El id no existe.',
                    'name.required' => 'El campo nombre es requerido.',
                    'name.string' => 'El campo nombre debe ser texto.',
                    'name.unique' => 'El nombre ya está registrado.'
                ]
            );

            $role = Role::find($request->id);
            $role->name = $request->name;
            $role->save();

            return response()->json([
                'success' => true,
                'message' => 'El rol se ha actualizado correctamente.'
            ], 200);
        }catch(ValidationException $e){
            return response()->json([
                'success' => false,
                'message' => 'Errores de Validación.',
                'errors' => $e->errors()
            ], 422);
        }
    }

    public function getRoles()
    {
        $roles = Role::all();

        return response()->json($roles);
    }

    public function assignRole(Request $request)
    {
        try{
            $request->validate(
                [
                    'user_id' => 'required|exists:users,id',
                    'role_id' => 'required|exists:roles,id'
                ],
                [
                    'user_id.required' => 'El campo usuario es requerido.',
                    'user_id.exists' => 'El usuario no existe.',
                    'role_id.required' => 'El campo rol es requerido.',
                    'role_id.exists' => 'El role no existe.'
                ]
            );

            $user = User::find($request->user_id);
            $user->roles()->sync($request->role_id);

            return response()->json([
                'success' => true,
                'message' => 'El rol se ha asignado correctamente.'
            ], 200);
        }catch(ValidationException $e){
            return response()->json([
                'success' => false,
                'message' => 'Errores de Validación.',
                'errors' => $e->errors()
            ], 422);
        }
    }

    public function removeRole(Request $request)
    {
        try{
            $request->validate(
                [
                    'user_id' => 'required|exists:users,id',
                    'role_id' => 'required|exists:roles,id'
                ],
                [
                    'user_id.required' => 'El campo usuario es requerido.',
                    'user_id.exists' => 'El usuario no existe.',
                    'role_id.required' => 'El campo rol es requerido.',
                    'role_id.exists' => 'El role no existe.'
                ]
            );

            $user = User::find($request->user_id);
            $user->roles()->detach($request->role_id);

            return response()->json([
                'success' => true,
                'message' => 'Se ha desasignado el rol del usuario correctamente.'
            ], 200);
        }catch(ValidationException $e){
            return response()->json([
                'success' => false,
                'message' => 'Errores de Validación.',
                'errors' => $e->errors()
            ], 422);
        }
    }

    public function deleteRole(Request $request)
    {
        try {
            $request->validate([
                'id' => 'required|exists:roles,id'
            ], [
                'id.required' => 'El campo id es requerido.',
                'id.exists' => 'El rol no existe.'
            ]);

            $role = Role::find($request->id);

            // Check if the role has any users assigned
            if ($role->users()->exists()) {
                return response()->json([
                    'success' => false,
                    'message' => 'No se puede eliminar el rol porque tiene usuarios asignados.'
                ], 422);
            }

            $role->delete();

            return response()->json([
                'success' => true,
                'message' => 'El rol se ha eliminado correctamente.'
            ], 200);
        } catch (ValidationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Errores de Validación.',
                'errors' => $e->errors()
            ], 422);
        }
    }
}

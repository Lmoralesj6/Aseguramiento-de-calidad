<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class CategoryController extends Controller
{
    public function create(Request $request)
    {
        try{
            $request->validate(
                [
                    'name' => 'required|string|unique:categories',
                    'description' => 'required|string'
                ],
                [
                    'name.required' => 'El campo nombre es requerido.',
                    'name.string' => 'El campo nombre debe ser texto.',
                    'name.unique' => 'El nombre ya está registrado.',
                    'description.required' => 'El campo descripción es requerido.',
                    'description.string' => 'El campo descripción debe ser texto.'
                ]
            );

            $category = Category::create([
                'name' => $request->name,
                'description' => $request->description
            ]);

            return response()->json([
                'success' => true,
                'message' => 'La categoria se ha creado correctamente.'
            ], 200);
        }catch(ValidationException $e){
            return response()->json([
                'success' => false,
                'message' => 'Errores de Validación.',
                'errors' => $e->errors()
            ], 422);
        }
    }

    public function update(Request $request)
    {
        try{
            $request->validate(
                [
                    'id' => 'required|exists:categories,id',
                    'name' => 'required|string|unique:categories,name,' . $request->id,
                    'description' => 'required|string'
                ],
                [
                    'id.required' => 'El campo id es requerido.',
                    'id.exists' => 'El id no existe.',
                    'name.required' => 'El campo nombre es requerido.',
                    'name.string' => 'El campo nombre debe ser texto.',
                    'name.unique' => 'El nombre ya está registrado.',
                    'description.required' => 'El campo descripción es requerido.',
                    'description.string' => 'El campo descripción debe ser texto.'
                ]
            );

            $category = Category::find($request->id);
            $category->name = $request->name;
            $category->description = $request->description;
            $category->save();

            return response()->json([
                'success' => true,
                'message' => 'La categoria se ha actualizado correctamente.'
            ], 200);
        }catch(ValidationException $e){
            return response()->json([
                'success' => false,
                'message' => 'Errores de Validación.',
                'errors' => $e->errors()
            ], 422);
        }
    }

    public function get()
    {
        try{
            $categorys = Category::all();
            return response()->json([
                'success' => true,
                'message' => 'Categorias obtenidas correctamente.',
                'categories' => $categorys
            ], 200);
        }catch(ValidationException $e){
            return response()->json([
                'success' => false,
                'message' => 'Ocurrió un error al obtener las categorias.',
            ], 422);
        }
    }

    public function delete(Request $request)
    {
        try{
            $request->validate(
                [
                    'id' => 'required|exists:categories,id'
                ],
                [
                    'id.required' => 'El campo id es requerido.',
                    'id.exists' => 'El id no existe.'
                ]
            );

            $category = Category::find($request->id);
            if ($category->products()->count() > 0) {
                return response()->json([
                    'success' => false,
                    'message' => 'No se puede eliminar la categoría porque tiene productos asociados.'
                ], 422);
            }
            $category->delete();

            return response()->json([
                'success' => true,
                'message' => 'La categoria se ha eliminado correctamente.'
            ], 200);
        }catch(ValidationException $e){
            return response()->json([
                'success' => false,
                'message' => 'Errores de Validación.',
                'errors' => $e->errors()
            ], 422);
        }
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\Quote;
use Illuminate\Http\Request;
use App\Mail\QuoteConfirmation;
use App\Mail\QuoteResponse;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;

class QuoteController extends Controller
{
    public function store(Request $request)
    {
        try {
            $request->validate(
                [
                    'name' => 'required|string|unique:quotes',
                    'email' => 'required|email',
                    'cellphone' => 'required|numeric',
                    'description' => 'required|string',
                    'image' => 'required|string',
                ],
                [
                    'name.required' => 'El campo nombre es requerido.',
                    'name.string' => 'El campo nombre debe ser texto.',
                    'name.unique' => 'El nombre ya está registrado.',
                    'email.required' => 'El campo correo electrónico es requerido.',
                    'email.email' => 'El formato del correo electrónico no es válido.',
                    'cellphone.required' => 'El campo teléfono es requerido.',
                    'cellphone.numeric' => 'El campo teléfono debe ser numérico.',
                    'description.required' => 'El campo descripción es requerido.',
                    'description.string' => 'El campo descripción debe ser texto.',
                    'image.required' => 'La imagen es requerida y debe ser una cadena en base64.',
                    'image.string' => 'La imagen debe ser una cadena en base64.'
                ]
            );

            $imageBase64 = $request->image;
            preg_match("/^data:image\/(.*);base64/i", $imageBase64, $match);
            $imageType = $match[1];
            $image = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $imageBase64));
            $imageName = time() . '.' . $imageType;

            // Guardar imagen en la carpeta public/quotes
            $path = Storage::disk('quotes')->put($imageName, $image);

            // Generar URL pública manualmente
            $imagePath = env('APP_URL') . '/quotes/' . $imageName;

            // Leer la imagen desde el disco y codificarla en base64
            $base64Image = 'data:image/' . $imageType . ';base64,' . base64_encode($image);

            $quote = Quote::create([
                'name' => $request->name,
                'email' => $request->email,
                'cellphone' => $request->cellphone,
                'description' => $request->description,
                'image' => env('APP_URL') . '/quotes/' . $imageName,
            ]);

            // Enviar correo de confirmación
            Mail::to($request->email)->send(new QuoteConfirmation($quote));

            return response()->json([
                'success' => true,
                'message' => 'Cotización creada correctamente.',
                'contact' => $quote,
            ], 200);
        } catch (ValidationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Errores de validación.',
                'errors' => $e->errors(),
            ], 422);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Ocurrió un error al almacenar la cotización.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function get()
    {
        $quotes = Quote::all();

        return response()->json([
            'success' => true,
            'quotes' => $quotes,
        ], 200);
    }

    public function send_response(Request $request)
    {
        try {
            $request->validate(
                [
                    'quote_id' => 'required|exists:quotes,id',
                    'message' => 'required|string',
                ],
                [
                    'quote_id.required' => 'El campo quote_id es requerido.',
                    'quote_id.exists' => 'La cotización no existe.',
                    'message.required' => 'El campo mensaje es requerido.',
                    'message.string' => 'El campo mensaje debe ser texto.',
                ]
            );

            $quote = Quote::find($request->quote_id);
            $request->merge(['name' => $quote->name]);
            $request->merge(['description' => $quote->description]);

            // Enviar correo de respuesta
            Mail::to($quote->email)->send(new QuoteResponse($request));

            return response()->json([
                'success' => true,
                'message' => 'Respuesta enviada correctamente.',
            ], 200);

        } catch(ValidationException $e){
            return response()->json([
                'success' => false,
                'message' => 'Errores de validación.',
                'errors' => $e->errors(),
            ], 422);
        } catch(\Exception $e){
            return response()->json([
                'success' => false,
                'message' => 'Ocurrió un error al enviar la respuesta.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

}

<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\QuoteController;
use App\Http\Controllers\ReviewController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\FavoriteController;
use App\Http\Controllers\ReportingController;
use App\Http\Controllers\Auth\ResetPasswordController;
use App\Http\Controllers\Auth\ForgotPasswordController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
*/
Route::post('register', [AuthController::class, 'register']);
Route::post('login', [AuthController::class, 'login']);
Route::post('password/email', [ForgotPasswordController::class, 'sendResetLinkEmail'])->name('password.email');
Route::post('password/reset', [ResetPasswordController::class, 'reset'])->name('password.update');
Route::get('password/reset/{token}', [ResetPasswordController::class, 'showResetForm'])->name('password.reset');

Route::get('get-products', [ProductController::class, 'get']);
Route::get('get-categories', [CategoryController::class, 'get']);
Route::post('contact', [ContactController::class, 'store']);
Route::get('get-contact', [ContactController::class, 'get']);
Route::post('quote', [QuoteController::class, 'store']);
Route::get('get-quotes', [QuoteController::class, 'get']);
Route::post('response-quote', [QuoteController::class, 'send_response']);

Route::middleware('auth:sanctum')->group(function () {
    //Auth
    Route::get('me', [AuthController::class, 'me']);
    Route::put('update', [AuthController::class, 'update']);
    Route::post('logout', [AuthController::class, 'logout']);
    Route::get('users', [AuthController::class, 'index']);
    //Roles
    Route::post('create-role', [RoleController::class, 'createRole']);
    Route::put('update-role', [RoleController::class, 'update']);
    Route::get('get-roles', [RoleController::class, 'getRoles']);
    Route::post('assign-role', [RoleController::class, 'assignRole']);
    Route::post('remove-role', [RoleController::class, 'removeRole']);
    Route::post('delete-role', [RoleController::class, 'deleteRole']);
    //Categories
    Route::post('create-category', [CategoryController::class, 'create']);
    Route::put('update-category', [CategoryController::class, 'update']);

    Route::post('delete-category', [CategoryController::class, 'delete']);
    //Products
    Route::post('create-product', [ProductController::class, 'create']);
    Route::put('update-product', [ProductController::class, 'update']);
    Route::post('delete-product', [ProductController::class, 'delete']);
    Route::post('add-fav', [ProductController::class, 'add_fav']);
    Route::get('get-favs', [ProductController::class, 'get_favs']);
    Route::post('delete-fav', [ProductController::class, 'remove_fav']);
    //Cart
    Route::post('create-cart', [CartController::class, 'create']);
    Route::post('add-item-cart', [CartController::class, 'addItem']);
    Route::get('get-cart-items', [CartController::class, 'getCartItems']);
    Route::get('get-cart', [CartController::class, 'getCart']);
    Route::put('update-cart-status', [CartController::class, 'updateCartStatus']);
    Route::post('delete-cart-item', [CartController::class, 'deleteCartItem']);
    Route::post('delete-cart', [CartController::class, 'delete']);
    //Reviews
    Route::post('create-review', [ReviewController::class, 'store']);
    //Orders
    Route::post('create-order', [OrderController::class, 'store']);
    Route::get('get-orders', [OrderController::class, 'get']);
    Route::get('get-all-orders', [OrderController::class, 'getAll']);
    Route::put('update-order-status', [OrderController::class, 'updateStatus']);
    //Reporting
    Route::get('best-selling-products', [ReportingController::class, 'bestSellingProductsReport']);
    Route::get('highest-ranking-products', [ReportingController::class, 'highestRankingProductsReport']);
    Route::get('most-favorited-products', [ReportingController::class, 'mostFavoritedProductsReport']);
    Route::get('get-product-chart-data', [ReportingController::class, 'getProductChartData']);


    //Favorites
    Route::post('create-favorite', [FavoriteController::class, 'store']);
});

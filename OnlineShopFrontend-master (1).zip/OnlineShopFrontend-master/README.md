# React + Vite

### How Run
```bash
git clone https://github.com/websolutionscorpgt/OnlineShopFrontend
cd OnlineShopFrontend
npm i 
npm run dev
```

### Project Structure
![image](https://github.com/user-attachments/assets/2388865b-448c-4268-ac74-d704f1ac3907)


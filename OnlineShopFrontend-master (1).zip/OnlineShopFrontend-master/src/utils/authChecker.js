
export const isLogged = () => {
  const token = JSON.parse(localStorage.getItem('token'));
  return token !== null;
}

export const isAdmin = (roles) => {
  return roles.filter((item) => item == "Administrador")[0] ? true : false
}

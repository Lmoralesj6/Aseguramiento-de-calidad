const products = [
  {
    id: 1,
    name: 'BRAND 1',
    description: 'Nice Chair, pink',
    price: 'Q.1100',
    price_old: 'Q.2700',
    img: 'https://images.unsplash.com/photo-1494228766058-1430438d10fc?q=80&w=1473&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    rating: 4,
    reviews: 10
  },
  {
    id: 2,
    name: 'BRAND 2',
    description: 'Nice Chair, pink',
    price: 'Q.1200',
    price_old: 'Q.2700',
    img: 'https://images.unsplash.com/photo-1494578379344-d6c710782a3d?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    rating: 2,
    reviews: 20
  },
  {
    id: 3,
    name: 'BRAND 3',
    description: 'Nice Chair, pink',
    price: 'Q.1300',
    price_old: 'Q.2700',
    img: 'https://images.unsplash.com/photo-1590736969955-71cc94801759?q=80&w=1527&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    rating: 5,
    reviews: 2
  }
]

export default products;

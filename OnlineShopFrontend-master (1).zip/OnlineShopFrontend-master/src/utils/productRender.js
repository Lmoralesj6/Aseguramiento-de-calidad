import { img_url } from "../config/config";
let defaultImg = 'https://images.unsplash.com/photo-1494228766058-1430438d10fc?q=80&w=1473&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D';

export const getUrl = (images) => {
  if (images.length === 0) return defaultImg;
  if (images.length > 0) {
    return images[0].base64;
  }
}

export const getObjectProduct = (item) => {
  var img_url = getUrl(item.images);
  return {
    id: item.id,
    name: item.name,
    description: item.description,
    rating: 5,
    price: item.price,
    price_old: parseFloat(item.price) + (parseFloat(item.price) * 0.15),
    reviews: 10,
    img: img_url,
  };
};



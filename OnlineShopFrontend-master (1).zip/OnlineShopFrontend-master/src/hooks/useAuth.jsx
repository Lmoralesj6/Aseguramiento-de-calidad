import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

function useAuthToken() {
  const [authToken, setAuthToken] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const token = JSON.parse(localStorage.getItem('token'));
    if (token) {
      setAuthToken(token);
    } else {
      navigate('/admin');
    }
  }, []);

  return authToken;
}

export default useAuthToken;


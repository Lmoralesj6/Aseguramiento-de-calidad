import React, { createContext, useReducer, useContext, useEffect } from 'react';
import { getFavorites, addFavorite, removeFavorite } from '../services/favoriteService';
import { useToast } from '@chakra-ui/react';

const FavoritesContext = createContext();

const favoritesReducer = (state, action) => {
  switch (action.type) {
    case 'SET':
      return action.favorites;

    case 'ADD':
      return [...state, action.item];

    case 'REMOVE':
      return state.filter((fav) => fav.id !== action.id);

    case 'CLEAR':
      return [];

    default:
      return state;
  }
};


export const FavoritesProvider = ({ children }) => {
  const toast = useToast();
  const [favorites, dispatch] = useReducer(favoritesReducer, [], () => {
    const localData = localStorage.getItem('favorites') !== null ? JSON.parse(localStorage.getItem('favorites')) : [];
    return localData;
  });

  useEffect(() => {
    const token = localStorage.getItem('token');
    const user = JSON.parse(localStorage.getItem('user'));
    if (!token || !user) return;

    const fetchFavorites = async () => {
      try {
        const response = await getFavorites(user.id);
        dispatch({ type: 'SET', favorites: response.data.products });
      } catch (error) {
        console.error('Error fetching favorites:', error);
      }
    };

    fetchFavorites();
  }, []);

  useEffect(() => {
    if (favorites) {
      localStorage.setItem('favorites', JSON.stringify(favorites));
    }
  }, [favorites]);

  const addToFavorites = async (product) => {
    try {
      await addFavorite(product.id);
    } catch (error) {

      console.error('Error adding to favorites', error);
    }
  };

  const clearFavorites = () => {
    dispatch({ type: 'CLEAR' });
  };

  const removeFromFavorites = async (product) => {
    try {
      await removeFavorite(product.id);
      dispatch({ type: 'REMOVE', item: product });
    } catch (error) {
      console.error('Error adding to favorites', error);
    }
  }

  return (
    <FavoritesContext.Provider value={{ favorites, addToFavorites, clearFavorites, removeFromFavorites }}>
      {children}
    </FavoritesContext.Provider>
  );
};

export const useFavorites = () => useContext(FavoritesContext);


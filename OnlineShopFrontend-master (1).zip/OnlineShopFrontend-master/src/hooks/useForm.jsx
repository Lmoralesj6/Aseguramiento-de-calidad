import { useState } from 'react';

const useForm = (initialState, onSubmit) => {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState([]);

  const handleChange = (e) => {
    cleanError(e.target.name);
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async () => {
    const response = await onSubmit(formData);
    if (!response.data) {
      const { error } = response;
      console.log(error);
      const result = Object.keys(error.errors).map((key) => ({ name: key, value: error.errors[key] }));
      setErrors(result);
      return;
    }
    return response.data;
  };

  const cleanError = (field) => {
    setErrors(prevErrors => prevErrors.filter(err => err.name !== field));
  };

  const getError = (field) => {
    const error = errors.find(err => err.name === field);
    return error ? error.value.join('\n') : '';
  };

  return {
    formData,
    errors,
    handleChange,
    handleSubmit,
    getError,
    setFormData,
  };
};

export default useForm;

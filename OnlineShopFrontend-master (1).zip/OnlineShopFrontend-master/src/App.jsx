import RouterManager from "./routes/RouteManager"
import { ChakraProvider } from "@chakra-ui/react"
import './assets/styles/common/global.css';
import { CartProvider } from "./hooks/CartContext";

function App() {
  return (
    <ChakraProvider>
      <CartProvider>
        <RouterManager />
      </CartProvider>
    </ChakraProvider>
  )
}

export default App

import handleRequest from "../utils/handleRequest";
import api from "./api";

export const addFavorite = async (prdId) => {
  const token = JSON.parse(localStorage.getItem('token'));
  const user = JSON.parse(localStorage.getItem('user'));

  return handleRequest(() =>
    api.post('/add-fav', { product_id: prdId, user_id: user.id }, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
  );
};



export const getFavorites = async (usrId) => {
  const token = JSON.parse(localStorage.getItem('token'));
  return handleRequest(() =>
    api.get(`/get-favs`, {
      params: { user_id: usrId },
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
  );
};



export const removeFavorite = async (prdId) => {
  const token = JSON.parse(localStorage.getItem('token'));
  const user = JSON.parse(localStorage.getItem('user'));

  return handleRequest(() =>
    api.post('/delete-fav', { product_id: prdId, user_id: user.id }, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
  );
};

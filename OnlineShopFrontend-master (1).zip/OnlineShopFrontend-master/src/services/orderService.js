import api from "./api";
import handleRequest from '../utils/handleRequest';

export const getOrders = async () => {
  const token = JSON.parse(localStorage.getItem('token'));
  return handleRequest(() =>
    api.get('/get-all-orders', {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
  );
};


export const deleteOrder = async () => {
  const token = JSON.parse(localStorage.getItem('token'));
  return handleRequest(() =>
    api.get('/get-all-orders', {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
  );
};


export const updateOrderStatus = async (id, orderStatus) => {
  const token = JSON.parse(localStorage.getItem('token'));
  return handleRequest(() =>
    api.put('/update-order-status', { id, status: orderStatus }, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
  );
};

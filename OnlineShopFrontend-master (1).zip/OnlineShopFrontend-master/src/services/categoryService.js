import api from "./api";
import handleRequest from '../utils/handleRequest';


export const getAll = async () => {
  return handleRequest(() => api.get('/get-products'));
}


export const createCategory = async (category) => {
  const token = JSON.parse(localStorage.getItem('token'));
  return handleRequest(() =>
    api.post('/create-category', category, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
  );
};

export const updateCategory = async (category) => {
  const token = JSON.parse(localStorage.getItem('token'));
  console.log(category);
  return handleRequest(() =>
    api.put('/update-category', category, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
  );
}

export const deleteCategory = async (categoryId) => {
  const token = JSON.parse(localStorage.getItem('token'));
  const r = { id: categoryId };
  return handleRequest(() =>
    api.post('/delete-category', r, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
  );
}

// Categories
export const getAllCategories = async () => {
  return handleRequest(() => api.get('/get-categories'));
}

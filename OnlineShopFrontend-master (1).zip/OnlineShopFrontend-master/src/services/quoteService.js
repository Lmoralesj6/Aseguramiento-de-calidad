import api from "./api";
import handleRequest from '../utils/handleRequest';

export const sendQuoteRequest = async (form) => {
  const token = JSON.parse(localStorage.getItem('token'));
  console.log(form);


  return handleRequest(() =>
    api.post('/quote', { ...form, cellphone: form.phone }, {
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'multipart/form-data',
      },
    })
  );
};

export const sendQuoteResponse = async (idQuoute, message) => {
  const token = JSON.parse(localStorage.getItem('token'));
  return handleRequest(() =>
    api.post('/response-quote', { quote_id: idQuoute, message: message }, {
      headers: {
        Authorization: `Bearer ${token}`
      },
    })
  );
};




export const getQuotes = async () => {
  return handleRequest(() => api.get('/get-quotes'));
}

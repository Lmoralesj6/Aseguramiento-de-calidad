import api from "./api";
import handleRequest from '../utils/handleRequest';


export const createReview = async (productId, comment, rating) => {
  const token = JSON.parse(localStorage.getItem('token'));
  return handleRequest(() =>
    api.post('/create-review', { product_id: productId, comment: comment, rating, rating }, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
  );
};

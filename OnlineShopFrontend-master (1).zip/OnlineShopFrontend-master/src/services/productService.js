import api from "./api";
import handleRequest from '../utils/handleRequest';


export const getAll = async () => {
  return handleRequest(() => api.get('/get-products'));
}


export const createProduct = async (prd) => {
  const token = JSON.parse(localStorage.getItem('token'));
  return handleRequest(() =>
    api.post('/create-product', prd, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
  );
};

export const updateProduct = async (product) => {
  const token = JSON.parse(localStorage.getItem('token'));
  return handleRequest(() =>
    api.put('/update-product', product, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
  );
}

export const deleteProduct = async (prdId) => {
  const token = JSON.parse(localStorage.getItem('token'));
  const r = { id: prdId };
  return handleRequest(() =>
    api.post('/delete-product', r, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
  );
}



export const getUserInfo = async () => {
  const token = JSON.parse(localStorage.getItem('token'));
  return handleRequest(() =>
    api.get('/me', {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
  );
};






// http://localhost:8000/api/create-cart





// Categories
export const getAllCategories = async () => {
  return handleRequest(() => api.get('/get-categories'));
}

import api from "./api";
import handleRequest from '../utils/handleRequest';


export const getContacts = async () => {
  return handleRequest(() => api.get('/get-contact'));
}



export const sendContactMessage = async (name, email, message) => {
  const token = JSON.parse(localStorage.getItem('token'));
  return handleRequest(() =>
    api.post('/contact', { name, email, message }, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
  );
}

import api from "./api";
import handleRequest from '../utils/handleRequest';
import { ADMIN_ROLE } from "../config/config";



export const getUsers = async () => {
  const token = JSON.parse(localStorage.getItem('token'));
  return handleRequest(() =>
    api.get('/users', {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
  );
};

export const asignRole = async (user_id) => {
  const token = JSON.parse(localStorage.getItem('token'));
  return handleRequest(() =>
    api.post('/assign-role', { user_id, role_id: ADMIN_ROLE }, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
  );
};

export const removeRole = async (user_id) => {
  const token = JSON.parse(localStorage.getItem('token'));
  return handleRequest(() =>
    api.post('/remove-role', { user_id, role_id: ADMIN_ROLE }, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
  );
}

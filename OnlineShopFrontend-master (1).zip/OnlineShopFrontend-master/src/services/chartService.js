import api from "./api";
import handleRequest from '../utils/handleRequest';

export const getDataChart = async () => {
  const token = JSON.parse(localStorage.getItem('token'));
  return handleRequest(() =>
    api.get('/get-product-chart-data', {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
  );
}

import handleRequest from "../utils/handleRequest";
import api from "./api";

export const createCart = async (cart, usrId) => {
  const token = JSON.parse(localStorage.getItem('token'));

  const formattedCart = {
    user_id: usrId,
    items: cart.map(item => ({
      id: item.id,
      cantidad: item.cantidad,
    }))
  };

  return handleRequest(() =>
    api.post('/create-cart', formattedCart, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
  );
};


export const getCartHistory = async () => {
  const token = JSON.parse(localStorage.getItem('token'));
  return handleRequest(() =>
    api.get(`/get-orders`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
  );
};

export const createOrder = async (cart, usrId, address) => {
  const token = JSON.parse(localStorage.getItem('token'));

  const formattedCart = {
    user_id: usrId,
    address: address,
    items: cart.map(item => ({
      product_id: item.id,    // Cambiado de "id" a "product_id"
      quantity: item.cantidad // Cambiado de "cantidad" a "quantity"
    })),
    
  };
  console.log(formattedCart);

  return handleRequest(() =>
    api.post('/create-order', formattedCart, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
  );
};





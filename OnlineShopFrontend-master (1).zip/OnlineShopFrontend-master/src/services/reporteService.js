import api from "./api";
import handleRequest from '../utils/handleRequest';



export const getBestSellings = async () => {
  const token = JSON.parse(localStorage.getItem('token'));
  return handleRequest(() =>
    api.get('/best-selling-products', {
      headers: {
        Authorization: `Bearer ${token}`,
      },
      responseType: 'blob',
    })
  );
};

export const getRankingProducts = async () => {
  const token = JSON.parse(localStorage.getItem('token'));
  return handleRequest(() =>
    api.get('/highest-ranking-products', {
      headers: {
        Authorization: `Bearer ${token}`,
      },
      responseType: 'blob',
    })
  );
};


export const getMostFavoriteProducts = async () => {
  const token = JSON.parse(localStorage.getItem('token'));
  return handleRequest(() =>
    api.get('/most-favorited-products', {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
  );
};

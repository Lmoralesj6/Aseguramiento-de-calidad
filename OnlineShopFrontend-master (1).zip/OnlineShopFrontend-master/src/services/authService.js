
import api from "./api";
import handleRequest from '../utils/handleRequest';

export const login = async (credentials) => {
  return handleRequest(() => api.post('/login', credentials));
}

export const register = async (user) => {
  return handleRequest(() => api.post('/register', user));
};





export const logout = async () => {
  const token = JSON.parse(localStorage.getItem('token'));
  return handleRequest(() =>
    api.post('/logout', {}, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
  );
};

import ContentSection from "../components/common/ContentSection";
import ImageCarousel from "../components/user/Carousel";
import ProductCardContainer from "../components/user/ProductCardContainer";
import HomeHero from "../components/user/HomeHero";
import { Badge, Center } from "@chakra-ui/react";
import Divider from "../components/common/Divider";
import './../assets/styles/common/Home.css'
import { Text, Stack } from "@chakra-ui/react";

const Home = () => {
  return (
    <div>
      <ContentSection>
        <ImageCarousel />
      </ContentSection>
      <br />
      <br />
      <div className="row" style={{ margin: 0, padding: 0 }}>
        <div className="col-md-2 ">
          <Badge colorScheme='green' marginLeft={10} padding={2} borderRadius={8} >Productos Nuevos</Badge>
        </div>
      </div>
      <ContentSection cstyle="mt-4 mb-4">
        <ProductCardContainer />
      </ContentSection>
      <Divider>
        <div className="divider-container">
          <h2 className="home-divider-text">OFERTAS</h2>
          <h5 className="home-divider-text">Descrubre las ofertas de la temporada!</h5>
          <Stack direction={'row'} align={'center'} justify={'center'}>
            <Text fontSize={'3xl'} color='white'>Q.</Text>
            <Text fontSize={'6xl'} color={'white'} fontWeight={800}>
              159
            </Text>
            <Text color={'gray.200'}>/blusa</Text>
          </Stack>
        </div>
      </Divider>
      <ContentSection cstyle="mt-4 mb-4 p-4">
        <HomeHero />
      </ContentSection>
    </div>
  )
}

export default Home;

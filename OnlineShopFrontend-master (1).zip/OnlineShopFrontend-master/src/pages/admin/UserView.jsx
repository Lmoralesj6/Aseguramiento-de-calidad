
import React, { useState, useEffect } from 'react';
import { getUsers } from '../../services/userService';
import DataTable from '../../components/admin/DataTable';
import Loader from '../../components/common/Loader';
import { TbUserUp, TbUserOff } from "react-icons/tb";
import { Button, useToast } from '@chakra-ui/react';
import { asignRole, removeRole } from '../../services/userService'; // Asegúrate de tener una función para remover roles
import { ADMIN_ROLE } from '../../config/config';

const UserView = () => {
  const [users, setUsers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const toast = useToast();

  const fetchUsers = async () => {
    setIsLoading(true);
    const response = await getUsers();
    if (response.status === 200) {
      setUsers(response.data.users);
    }
    setIsLoading(false);
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const columns = [
    { header: 'ID', accessor: 'id' },
    { header: 'Nombre', accessor: 'name' },
    { header: 'Email', accessor: 'email' },
    { header: 'Fecha Creación', accessor: 'created_at' }
  ];

  const promover = async (id) => {
    const response = await asignRole(id);
    if (response.status === 200) {
      toast({
        title: 'Acción Realizada',
        description: 'Usuario promovido a Administrador',
        status: 'success',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right'
      });
      fetchUsers(); // Refrescamos la lista de usuarios
      return;
    }
    toast({
      title: 'Acción Denegada',
      description: 'Error al promover usuario',
      status: 'error',
      duration: 3000,
      isClosable: true,
      position: 'bottom-right'
    });
  };

  const desasignar = async (id) => {
    const response = await removeRole(id, ADMIN_ROLE);
    if (response.status === 200) {
      toast({
        title: 'Acción Realizada',
        description: 'Rol de Administrador removido',
        status: 'success',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right'
      });
      fetchUsers();
      return;
    }
    toast({
      title: 'Acción Denegada',
      description: 'Error al remover rol de Administrador',
      status: 'error',
      duration: 3000,
      isClosable: true,
      position: 'bottom-right'
    });
  };

  const renderActions = (user) => {
    const isAdmin = user.roles.some((role) => role.id === ADMIN_ROLE);
    return (
      <>
        {!isAdmin && (
          <Button p={0} color='blue.600' variant='outline' borderColor='blue.600' title='Promover a Administrador' onClick={() => promover(user.id)}>
            <TbUserUp />
          </Button>
        )}
        {isAdmin && (
          <Button p={0} color='red.600' variant='outline' _hover={{ bg: 'red.100' }} borderColor='red.600' title='Remover Administrador' onClick={() => desasignar(user.id)}>
            <TbUserOff />
          </Button>
        )}
      </>
    );
  };

  return (
    <>
      <Loader isLoading={isLoading} />
      {!isLoading && (
        <div className='datatable-container'>
          <DataTable
            columns={columns}
            data={users}
            renderActions={renderActions}
          />
        </div>
      )}
    </>
  );
};

export default UserView;


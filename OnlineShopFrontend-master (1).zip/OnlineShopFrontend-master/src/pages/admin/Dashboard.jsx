import React, { useState, useEffect } from "react";
import { Container, SimpleGrid, Box } from "@chakra-ui/react";
import { Line, Bar, Pie, Radar } from "react-chartjs-2";
import { getDataChart } from "../../services/chartService";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  PointElement,
  LineElement,
  ArcElement,
  RadialLinearScale,
} from "chart.js";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  PointElement,
  LineElement,
  ArcElement,
  RadialLinearScale
);

const Dashboard = () => {
  const [soldProductsData, setSoldProductsData] = useState(null);
  const [ratedProductsData, setRatedProductsData] = useState(null);
  const [favoriteProductsData, setFavoriteProductsData] = useState(null);
  const [performanceData, setPerformanceData] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      const response = await getDataChart();

      if (response.status === 200) {
        const { bestSellingProducts, highestRankingProducts, mostFavoritedProducts } = response.data;

        // Preparar datos para productos más vendidos
        const soldProducts = {
          labels: bestSellingProducts.map(product => product.name),
          datasets: [
            {
              label: "Ventas",
              data: bestSellingProducts.map(product => product.quantity_sold),
              backgroundColor: "rgba(75, 192, 192, 0.6)",
            },
          ],
        };

        // Preparar datos para productos mejor calificados
        const ratedProducts = {
          labels: highestRankingProducts.map(product => product.name),
          datasets: [
            {
              label: "Calificaciones",
              data: highestRankingProducts.map(product => product.average_rating),
              backgroundColor: "rgba(153, 102, 255, 0.6)",
            },
          ],
        };

        // Preparar datos para productos más agregados a favoritos
        const favoritedProducts = {
          labels: mostFavoritedProducts.map(product => product.name),
          datasets: [
            {
              label: "Favoritos",
              data: mostFavoritedProducts.map(product => product.favorites_count),
              backgroundColor: "rgba(255, 159, 64, 0.6)",
            },
          ],
        };

        // Preparar datos para gráfica de radar de rendimiento
        const performance = {
          labels: ["Ventas", "Calificaciones", "Favoritos"],
          datasets: [
            {
              label: "Producto A",
              data: [
                bestSellingProducts[0]?.quantity_sold || 0,
                highestRankingProducts[0]?.average_rating || 0,
                mostFavoritedProducts[0]?.favorites_count || 0,
              ],
              backgroundColor: "rgba(255, 99, 132, 0.5)",
            },
            // Puedes agregar más productos si los tienes disponibles
          ],
        };

        setSoldProductsData(soldProducts);
        setRatedProductsData(ratedProducts);
        setFavoriteProductsData(favoritedProducts);
        setPerformanceData(performance);
      }
    };

    fetchData();
  }, []);

  if (!soldProductsData || !ratedProductsData || !favoriteProductsData || !performanceData) {
    return <p>Cargando datos...</p>;
  }

  return (
    <Container maxW="container.xl">
      <SimpleGrid columns={{ sm: 1, md: 2 }} spacing={10}>
        <Box p={10}>
          <h3>Productos más vendidos</h3>
          <Bar data={soldProductsData} options={{ responsive: true }} />
        </Box>
        <Box p={10}>
          <h3>Productos mejor calificados</h3>
          <Line data={ratedProductsData} options={{ responsive: true }} />
        </Box>
        <Box p={10}>
          <h3>Productos más agregados a favoritos</h3>
          <Pie data={favoriteProductsData} options={{ responsive: true }} />
        </Box>
        <Box p={10}>
          <h3>Rendimiento de productos</h3>
          <Radar data={performanceData} options={{ responsive: true }} />
        </Box>
      </SimpleGrid>
    </Container>
  );
};

export default Dashboard;

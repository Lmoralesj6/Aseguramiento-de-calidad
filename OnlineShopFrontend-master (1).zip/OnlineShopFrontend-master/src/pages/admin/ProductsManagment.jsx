import { Heading, Text } from "@chakra-ui/react";
import ProductCreator from "../../components/admin/ProductCreator";


const ProductsManagment = () => {
  return (
    <div className="pb-4 mt-4">
      <div className="container">
        <div className="row">
          <div className="col-md-8 mx-auto border p-4 rounded shadow-lg">
            <Heading
              marginTop='2rem'
              textAlign='center'
              marginLeft={'auto'}
              fontWeight={600}
              fontSize={{ base: '1xl', sm: '2xl', md: '4xl' }}
              lineHeight={'110%'}>
              Gestión de <br />
              <Text as={'span'} color={'teal.400'}>
                Productos
              </Text>
            </Heading>

            <ProductCreator />

          </div>
        </div>
      </div>

    </div>
  );
}


export default ProductsManagment;

import React, { useState, useEffect } from "react";
import { getOrders, deleteOrder } from "../../services/orderService";
import { getContacts } from "../../services/contactService";
import { useToast, Button } from '@chakra-ui/react';
import DataTable from '../../components/admin/DataTable';
import { FaTrash, FaEdit } from "react-icons/fa";
import ConfirmDialog from '../../components/common/ConfirmDialog';
import Loader from '../../components/common/Loader'; // Importar el Loader
import { useNavigate } from 'react-router-dom';
import { Box, Badge, Heading } from '@chakra-ui/react';
import { IoMdSend } from "react-icons/io";

const ContactView = () => {
  const [contacts, setContacts] = useState([]);
  const [isLoading, setIsLoading] = useState(true); // Estado de carga
  const [selectedOrderId, setSelectedOrderId] = useState(null);
  const [isOpen, setIsOpen] = useState(false);
  const toast = useToast();
  const history = useNavigate();

  const fetchContacts = async () => {
    setIsLoading(true);
    const response = await getContacts();
    if (response.status === 200) {
      /* console.log(response.data.contacts); */
      setContacts(response.data.contacts);
    }
    setIsLoading(false);
  };

  useEffect(() => {
    fetchContacts();
  }, []);

  const handleDeleteClick = (id) => {
    setSelectedOrderId(id);
    setIsOpen(true);
  };

  const _deleteOrder = async () => {
    const response = await deleteOrder(selectedOrderId);
    if (response.status === 200) {
      toast({
        title: 'Acción Realizada',
        description: 'Orden Eliminada',
        status: 'success',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right',
      });
      fetchOrders();
    }
    setIsOpen(false);
  };


  const columns = [
    { header: 'ID', accessor: 'id' },
    { header: 'Nombre', accessor: 'name' },
    { header: 'Correo', accessor: 'email' },
    { header: 'Mensaje', accessor: 'message' },
    { header: 'Fecha de Creación', accessor: 'created_at' },
  ];

  const edit = (id) => {
    history(`/admin/order/editar/${id}`);
  }

  return (
    <Box p={'4rem'}>
      <Heading>Listado de Contactos</Heading>
      <Loader isLoading={isLoading} />

      {!isLoading && (
        <>
          <div className='datatable-container'>
            <DataTable
              columns={columns}
              data={contacts}
              renderActions={(item) => (
                <>
                <Button p={0} color='blue.600' variant='outline' borderColor='blue.600' title='Responder' onClick={() => edit(item.id)}><IoMdSend /></Button>
                  {/* <Button p={0} color='blue.600' variant='outline' borderColor='blue.600' title='Editar' onClick={() => edit(item.id)}><FaEdit /></Button>
                  <Button p={0} color='blue.600' variant='outline' borderColor='blue.600' title='Eliminar' onClick={() => handleDeleteClick(item.id)}><FaTrash /></Button> */}
                </>
              )}
            />
          </div>
          <ConfirmDialog
            isOpen={isOpen}
            onClose={() => setIsOpen(false)}
            question="¿Estás seguro que deseas eliminar esta orden?"
            onConfirm={_deleteOrder}
          />
        </>
      )}
    </Box>
  );
};

export default ContactView;

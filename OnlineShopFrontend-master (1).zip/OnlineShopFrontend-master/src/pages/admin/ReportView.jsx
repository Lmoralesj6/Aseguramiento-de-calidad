
import { Text, Box, HStack, Button } from "@chakra-ui/react";
import { getBestSellings, getRankingProducts } from "../../services/reporteService";
import React from "react";

const ReportView = () => {
  const fetchBestSellings = async () => {
    const response = await getBestSellings();

    if (response && response.data) {
      const blob = new Blob([response.data], { type: 'application/pdf' });
      const link = document.createElement('a');
      link.href = window.URL.createObjectURL(blob);
      link.download = 'BestSellingProducts.pdf';
      link.click();
    } else {
      console.error('Failed to fetch the PDF');
    }
  };


  const fetchRankingProducts = async () => {
    const response = await getRankingProducts();
    console.log(response);
    if (response && response.data) {
      const blob = new Blob([response.data], { type: 'application/pdf' });
      const link = document.createElement('a');
      link.href = window.URL.createObjectURL(blob);
      link.download = 'RankingProducts.pdf';
      link.click();
    } else {
      console.error('Failed to fetch the PDF');
    }
  }

  return (
    <div className="p-4 m-4">
      <Text color="blue.500" fontWeight="bold" fontSize="1.4rem">Reportes</Text>
      <HStack p={10}>
        <Box _hover={{ bg: 'gray.300', cursor: 'pointer' }} bg="gray.200" w="100%" p={4} color="gray.500" textAlign="center" borderRadius={10} boxShadow="lg" onClick={fetchBestSellings}>
          Productos más vendidos
        </Box>
        <Box _hover={{ bg: 'gray.300', cursor: 'pointer' }} bg="gray.200" w="100%" p={4} color="gray.500" textAlign="center" borderRadius={10} boxShadow="lg" onClick={fetchRankingProducts}>
          Ranking de Productos
        </Box>
      </HStack>
    </div>
  );
};

export default ReportView;


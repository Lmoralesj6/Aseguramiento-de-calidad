
import React, { useState, useEffect } from "react";
import { getQuotes, sendQuoteResponse } from "../../services/quoteService";
import {
  Textarea,
  useToast,
  Button,
  Box,
  Popover,
  PopoverTrigger,
  PopoverContent,
  PopoverArrow,
  PopoverCloseButton,
  PopoverHeader,
  PopoverBody,
  Input,
  PopoverFooter,
  HStack,
  useDisclosure
} from '@chakra-ui/react';
import DataTable from '../../components/admin/DataTable';
import Loader from '../../components/common/Loader';
import { IoMdSend } from "react-icons/io";

const QuoteView = () => {
  const [quotes, setQuotes] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedQuote, setSelectedQuote] = useState(null);
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [isSending, setIsSending] = useState(false); // For loading state of the "Enviar" button
  const toast = useToast();

  const fetchQuotes = async () => {
    setIsLoading(true);
    const response = await getQuotes();
    if (response.status === 200) {
      setQuotes(response.data.quotes);
    }
    setIsLoading(false);
  };

  useEffect(() => {
    fetchQuotes();
  }, []);

  const columns = [
    { header: 'ID', accessor: 'id' },
    { header: 'Nombre', accessor: 'name' },
    { header: 'Correo', accessor: 'email' },
    { header: 'Descripción', accessor: 'description' },
    { header: 'Celular', accessor: 'cellphone' },
    { header: 'Fecha de Creación', accessor: 'created_at' },
  ];

  const handleSend = async () => {
    setIsSending(true); // Set loading state for the button
    const response = await sendQuoteResponse(selectedQuote.id, message);

    if (response.status === 200) {
      toast({
        title: 'Cotización Respondida',
        description: 'Respuesta enviada correctamente',
        status: 'success',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right'
      });
    } else {
      toast({
        title: 'Error',
        description: 'Error enviando respuesta de cotización',
        status: 'error',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right'
      });
    }

    setIsSending(false); // Reset loading state for the button
    setEmail('');
    setMessage('');
    setSelectedQuote(null);
  };

  const reply = (quote) => {
    setSelectedQuote(quote);
    setEmail(quote.email);
  };

  return (
    <Box mt={12}>
      <Loader isLoading={isLoading} />
      {!isLoading && (
        <>
          <DataTable
            columns={columns}
            data={quotes}
            title="Cotizaciones"
            renderActions={(item) => (
              <Popover>
                <PopoverTrigger>
                  <Button
                    p={0}
                    color='blue.600'
                    variant='outline'
                    borderColor='blue.600'
                    title='Responder'
                    onClick={() => reply(item)}
                  >
                    <IoMdSend />
                  </Button>
                </PopoverTrigger>
                <PopoverContent boxShadow='dark-lg' p='6' rounded='md'>
                  <PopoverArrow />
                  <PopoverCloseButton />
                  <PopoverHeader color='gray.600' fontWeight='bold'>Responder Cotización</PopoverHeader>
                  <PopoverBody>
                    <HStack>
                      <Input
                        placeholder="Email"
                        value={email}
                        readOnly={true}
                        background='gray.200'
                        border='none'
                      />
                    </HStack>
                    <HStack mt={4}>
                      <Textarea
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        placeholder="Mensaje"
                        background='gray.200'
                        border='none'
                      />
                    </HStack>
                  </PopoverBody>
                  <PopoverFooter>
                    <Button
                      colorScheme="blue"
                      onClick={handleSend}
                      isLoading={isSending} // This will show the loading spinner
                    >
                      Enviar
                    </Button>
                  </PopoverFooter>
                </PopoverContent>
              </Popover>
            )}
          />
        </>
      )}
    </Box>
  );
};

export default QuoteView;



import React, { useState, useEffect } from 'react';
import { getAll, deleteProduct } from '../../services/productService';
import { useToast, Button } from '@chakra-ui/react';
import DataTable from '../../components/admin/DataTable';
import { FaTrash, FaEdit } from "react-icons/fa";
import ConfirmDialog from '../../components/common/ConfirmDialog';
import RatingProduct from '../../components/user/RatingProduct';
import { Box, Image, Badge } from '@chakra-ui/react';
import Loader from '../../components/common/Loader'; // Importar el Loader
import { useNavigate } from 'react-router-dom';

const ProductView = () => {
  const [products, setProducts] = useState([]);
  const [isLoading, setIsLoading] = useState(true); // Estado de carga
  const [selectedProductId, setSelectedProductId] = useState(null);
  const [isOpen, setIsOpen] = useState(false);
  const toast = useToast();
  const history = useNavigate();

  const fetchProducts = async () => {
    setIsLoading(true); // Iniciar carga
    const response = await getAll();
    if (response.status === 200) {
      setProducts(response.data.products);
    }
    setIsLoading(false); // Finalizar carga
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const handleDeleteClick = (id) => {
    setSelectedProductId(id);
    setIsOpen(true);
  };

  const _deleteProduct = async () => {
    const response = await deleteProduct(selectedProductId);
    if (response.status === 200) {
      toast({
        title: 'Acción Realizada',
        description: 'Producto Eliminado',
        status: 'success',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right',
      });
      fetchProducts();
    }
    setIsOpen(false);
  };

  const columns = [
    { header: 'ID', accessor: 'id' },
    { header: 'Nombre', accessor: 'name' },
    { header: 'Descripción', accessor: 'description' },
    { header: 'Precio', accessor: 'price' },
    { header: 'Categoría', accessor: 'category.name', render: (category) => <Badge colorScheme="blackAlpha">{category}</Badge> },
    { header: 'Imagen', accessor: 'images', render: (images) => images && images.length > 0 && <Image boxSize="50px" src={images[0].base64} alt="producto" /> },
    { header: 'Rating Promedio', accessor: 'reviews', render: (reviews) => reviews.length > 0 ? <RatingProduct rating={reviews.reduce((acc, review) => acc + review.rating, 0) / reviews.length} /> : 'Sin calificaciones' }
  ];

  const edit = (id) => {
    history(`/admin/producto/editar/${id}`); 
  }

  return (
    <Box p={'4rem'}>
      <Loader isLoading={isLoading} />

      {!isLoading && (
        <>
          <div className='datatable-container'>
            <DataTable
              columns={columns}
              data={products}
              renderActions={(item) => (
                <>
                  <Button p={0} color='blue.600' variant='outline' borderColor='blue.600' title='Editar' onClick={() => edit(item.id)}><FaEdit /></Button>
                  <Button p={0} color='blue.600' variant='outline' borderColor='blue.600' title='Eliminar' onClick={() => handleDeleteClick(item.id)}><FaTrash /></Button>
                </>
              )}
            />
          </div>
          <ConfirmDialog
            isOpen={isOpen}
            onClose={() => setIsOpen(false)}
            question="¿Estás seguro que deseas eliminar este producto?"
            onConfirm={_deleteProduct}
          />
        </>
      )}
    </Box>
  );
};

export default ProductView;


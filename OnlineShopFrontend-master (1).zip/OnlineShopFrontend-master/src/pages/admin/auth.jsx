import Login from "../../components/common/Login";
import { login } from "../../services/authService";

const Auth = () => {
  return (
    <Login title='Administrador' service={login} route='/admin/dashboard' _type='private' />
  )
}

export default Auth;

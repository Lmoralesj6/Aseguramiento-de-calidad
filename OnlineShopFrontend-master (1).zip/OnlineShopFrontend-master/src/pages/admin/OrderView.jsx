import React, { useState, useEffect } from "react";
import { getOrders, deleteOrder, updateOrderStatus } from "../../services/orderService";
import { useToast, Button } from '@chakra-ui/react';
import DataTable from '../../components/admin/DataTable';
import { FaFilter } from "react-icons/fa";
import ConfirmDialog from '../../components/common/ConfirmDialog';
import Loader from '../../components/common/Loader'; // Importar el Loader
import { useNavigate } from 'react-router-dom';
import { Flex, Box, Badge, Icon, Select } from '@chakra-ui/react';

const OrderView = () => {
  const [orders, setOrders] = useState([]);
  const [isLoading, setIsLoading] = useState(true); // Estado de carga
  const [selectedOrderId, setSelectedOrderId] = useState(null);
  const [isOpen, setIsOpen] = useState(false);
  const toast = useToast();
  const history = useNavigate();

  const fetchOrders = async () => {
    setIsLoading(true);
    const response = await getOrders();
    if (response.status === 200) {
      setOrders(response.data.orders);
    }
    setIsLoading(false);
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  const handleDeleteClick = (id) => {
    setSelectedOrderId(id);
    setIsOpen(true);
  };

  const _deleteOrder = async () => {
    const response = await deleteOrder(selectedOrderId);
    if (response.status === 200) {
      toast({
        title: 'Acción Realizada',
        description: 'Orden Eliminada',
        status: 'success',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right',
      });
      fetchOrders();
    }
    setIsOpen(false);
  };


  const columns = [
    { header: 'ID', accessor: 'id' },
    { header: 'Usuario ID', accessor: 'user_id' },
    { header: 'Total', accessor: 'total' },
    { header: 'Estado', accessor: 'status', render: (status) => <Badge colorScheme={getColor(status).split('.')[0]}>{status}</Badge> },
    { header: 'Fecha de Creación', accessor: 'created_at' },
  ];

  const edit = (id) => {
    history(`/admin/order/editar/${id}`);
  }

  const statusChange = async (e, id) => {
    const value = e.target.value;
    const response = await updateOrderStatus(id, value);
    if (response.status == 200) {
      toast({
        title: 'Orden actualizada',
        description: `Orden actualizada a ${value}`,
        status: 'success',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right',
      });
      fetchOrders();
    }
  }

  const getColor = (status) => {
    if (status == 'pending') return 'red.500';
    if (status == 'completed') return 'green.400';
    return 'yellow.400';
  }

  const status_options = ['pending', 'process', 'completed'];

  return (
    <Box p={'4rem'}>
      <Loader isLoading={isLoading} />
      {!isLoading && (
        <>
          <div className='datatable-container'>
            <Select icon={<FaFilter />} bg="gray.200" placeholder=" " w={10} >
              <option value="Pendientes">Pendientes</option>
              <option value="Proceso">Proceso</option>
              <option value="Terminadas">Terminadas</option>
            </Select>
            <br />
            <DataTable
              columns={columns}
              title="Tablero de Ordenes"
              data={orders}
              renderActions={(item) => (
                <Flex justifyContent='center'>
                  <Select value={item.status} bg={getColor(item.status)} icon={''} onChange={(e) => statusChange(e, item.id)} size='xs' className="status-select">
                    {
                      status_options.map((_option, index) => (
                        <option defaultValue={item.status == _option} value={_option} key={index}>{_option.toUpperCase()}</option>
                      ))
                    }
                  </Select>
                </Flex>
              )}
            />
          </div>
          <ConfirmDialog
            isOpen={isOpen}
            onClose={() => setIsOpen(false)}
            question="¿Estás seguro que deseas eliminar esta orden?"
            onConfirm={_deleteOrder}
          />
        </>
      )}
    </Box>
  );
};

export default OrderView;

import React, { useState, useEffect } from 'react';
import { getAllCategories, deleteCategory } from '../../services/categoryService'; // Asegúrate de tener estos servicios
import {
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Box,
  Stack,
  Text,
  Badge,
  useToast,
  Button,
  HStack,
  useDisclosure,
  Select,
} from '@chakra-ui/react';
import { FaTrash, FaEdit } from "react-icons/fa";
import ConfirmDialog from '../../components/common/ConfirmDialog';
import { useNavigate } from 'react-router-dom';

const CategoryView = () => {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [categories, setCategories] = useState([]);
  const [currentPage, setCurrentPage] = useState(1); // Página actual
  const [categoriesPerPage, setCategoriesPerPage] = useState(5); // Categorías por página
  const [selectedCategoryId, setSelectedCategoryId] = useState(null); // ID de la categoría seleccionada para eliminar
  const toast = useToast();
  const history = useNavigate();

  const edit = (id) => {
    history(`/admin/categoria/editar/${id}`); 
  }

  const handleDeleteClick = (id) => {
    setSelectedCategoryId(id);
    onOpen();
  };

  const _deleteCategory = async () => {
    const response = await deleteCategory(selectedCategoryId);
    if (response.status === 200) {
      toast({
        title: 'Acción Realizada',
        description: 'Categoría Eliminada',
        status: 'success',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right',
      });
      fetchCategories();
    }
    onClose();
  };

  const fetchCategories = async () => {
    const response = await getAllCategories();
    if (response.status === 200) {
      setCategories(response.data.categories);
    }
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  const indexOfLastCategory = currentPage * categoriesPerPage;
  const indexOfFirstCategory = indexOfLastCategory - categoriesPerPage;
  const currentCategories = categories.slice(indexOfFirstCategory, indexOfLastCategory);

  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  const totalPages = Math.ceil(categories.length / categoriesPerPage);

  return (
    <Box p={'4rem'}>
      <HStack justifyContent="flex-start" mt={4}>
        <Text>Mostrar:</Text>
        <Select
          value={categoriesPerPage}
          onChange={(e) => setCategoriesPerPage(Number(e.target.value))}
          w="100px"
        >
          <option value={5}>5</option>
          <option value={10}>10</option>
          <option value={15}>15</option>
        </Select>
      </HStack>
      <Table variant="striped" colorScheme="blue" mt={10} boxShadow='base' rounded='md'>
        <Thead>
          <Tr>
            <Th>ID</Th>
            <Th>Nombre</Th>
            <Th>Descripción</Th>
            <Th textAlign='center'>Acciones</Th>
          </Tr>
        </Thead>
        <Tbody>
          {currentCategories.map((category, index) => (
            <Tr key={index}>
              <Td>{category.id}</Td>
              <Td>{category.name}</Td>
              <Td>{category.description}</Td>
              <Td>
                <Stack display='flex' flexDir='row'>
                  <Button p={0} color='blue.600' variant='outline' borderColor='blue.600' title='Editar' onClick={() => edit(category.id)}><FaEdit /></Button>
                  <Button p={0} color='blue.600' variant='outline' borderColor='blue.600' title='Eliminar' onClick={() => handleDeleteClick(category.id)}><FaTrash /></Button>
                </Stack>
              </Td>
            </Tr>
          ))}
        </Tbody>
      </Table>

      {/* Modal de Confirmación */}
      <ConfirmDialog
        isOpen={isOpen}
        onClose={onClose}
        question="¿Estás seguro que deseas eliminar esta categoría?"
        onConfirm={_deleteCategory}
      />

      {/* Paginación */}
      <HStack justifyContent="center" mt={4}>
        {Array.from({ length: totalPages }, (_, index) => (
          <Button
            key={index}
            onClick={() => paginate(index + 1)}
            isActive={currentPage === index + 1}
            colorScheme="blue"
          >
            {index + 1}
          </Button>
        ))}
      </HStack>
    </Box>
  );
};

export default CategoryView;

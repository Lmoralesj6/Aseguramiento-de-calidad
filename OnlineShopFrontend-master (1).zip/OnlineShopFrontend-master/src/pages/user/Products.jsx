import { getAll } from "../../services/productService";
import { useEffect, useState, useRef } from "react";
import { useParams } from "react-router-dom";
import {
  SimpleGrid,
} from "@chakra-ui/react";
import ProductCard from "../../components/user/ProductCard";
import ProductCardContainer from "../../components/user/ProductCardContainer";
import PriceRangeFilter from "../../components/user/PriceRangeFilter";
import { getUrl, getObjectProduct } from '../../utils/productRender.js'

const Products = () => {
  const [prds, setPrds] = useState([]);
  const [products, setProducts] = useState([]); // Toda la data real
  const { id } = useParams();
  const searchText = useRef();
  const priceRange = [0, 1000];

  const fetch = async () => {
    const response = await getAll();
    if (response.status === 200) {
      const { products } = response.data;
      var filtered = products.filter((item) => item.category_id == id);
      setPrds(filtered);
      setProducts(filtered);
    }
  };

  useEffect(() => {
    fetch();
  }, []);



  const buscar = (e) => {
    if (e.key === "Enter") {
      // texto a buscar
      const text = searchText.current.value.toLowerCase();
      // Filtramos
      const filteredData = products.filter((item) =>
        Object.values(item).some(
          (value) =>
            typeof value === "string" && value.toLowerCase().includes(text)
        )
      );
      setPrds(filteredData);
    }
  };

  const handlePriceChange = (value) => {
    const filteredData = products.filter(
      (item) => parseFloat(item.price) <= value
    );
    console.log(filteredData);
    setPrds(filteredData);
  };

  return (
    <div className="container">
      <div className="row">
        <div className="container m-4">
          <input
            type="text"
            className="form-control"
            placeholder="Ingrese el nombre del producto a buscar y presione Enter"
            ref={searchText}
            onKeyDown={buscar}
          />
        </div>
        <div className="container m-4">
          <PriceRangeFilter
            minPrice={priceRange[0]}
            maxPrice={priceRange[1]}
            onPriceChange={handlePriceChange}
          />
        </div>
        <ProductCardContainer>
          <SimpleGrid columns={{ sm: 2, md: 3, lg: 4 }} spacing="2rem">
            {prds && prds.length > 0
              ? prds.map((item, index) => (
                <ProductCard key={item.id || index} Product={getObjectProduct(item)} />
              ))
              : "No hay productos"}
          </SimpleGrid>
        </ProductCardContainer>
      </div>
    </div>
  );
};

export default Products;

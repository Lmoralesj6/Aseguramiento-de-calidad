import { getAll } from "../../services/productService";
import React from "react";
import { SimpleGrid } from "@chakra-ui/react";
import ProductCardContainer from "../../components/user/ProductCardContainer";
import ProductCard from "../../components/user/ProductCard";

const ProductsGrid = () => {

  const [products, setProducts] = React.useState([]);

  const fetch = async () => {
    const response = await getAll();
    if (response.status == 200) {
      setProducts(response.data.products);
    }
  }

  React.useEffect(() => {
    fetch();
  }, []);

  return (
    <div>
      <ProductCardContainer >
        <SimpleGrid columns={{ sm: 2, md: 2, lg: 3 }} spacing="0rem" padding={8}>
          {products && products.length > 0 ?
            (
              products.map((item, index) => (
                <ProductCard key={index} Product={item} />
              ))
            ) : 'Sin Productos'
          }
        </SimpleGrid>
      </ProductCardContainer>
    </div>
  );
}

export default ProductsGrid;

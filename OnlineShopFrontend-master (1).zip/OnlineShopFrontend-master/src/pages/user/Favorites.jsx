import { SimpleGrid, Box, Heading, Stack, Text, Image, Button } from '@chakra-ui/react';
import { useNavigate } from 'react-router-dom';
import { useFavorites } from '../../hooks/FavoritesProvider';
import { useEffect } from 'react';
import ProductCard from '../../components/user/ProductCard';
import ProductCardContainer from '../../components/user/ProductCardContainer';

const Favorites = () => {
  const { favorites } = useFavorites();
  const history = useNavigate();

  useEffect(() => {
    console.log(favorites);
  }, [favorites]);



  return (
    <div>
      <Heading
        marginTop={8}
        textAlign='center'
        fontWeight={600}
        fontSize={{ base: '2xl', sm: '1xl', md: '3xl' }}
        lineHeight={'110%'}>
        Tus productos {''}
        <Text as={'span'} color={'pink.400'}>
          Favoritos
        </Text>
      </Heading>
      <ProductCardContainer >
        <SimpleGrid columns={{ sm: 2, md: 2, lg: 3 }} spacing="0rem" padding={8}>
          {favorites && favorites.length > 0 ?
            (
              favorites.map((item, index) => (
                <ProductCard key={index} Product={item} />
              ))
            ) : 'Sin Favoritos'
          }
        </SimpleGrid>
      </ProductCardContainer>
    </div>
  );
}

export default Favorites;

import Cart from '../../components/user/Cart';

const PaymentCart = () => {
  return (
    <div>
      <Cart />
    </div>
  );
}


export default PaymentCart;

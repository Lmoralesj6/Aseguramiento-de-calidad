
import {
  Container,
  Flex,
  Box,
  Heading,
  Text,
  IconButton,
  VStack,
  HStack,
  Wrap,
  WrapItem,
} from '@chakra-ui/react'
import { BsTiktok, BsWhatsapp, BsInstagram } from 'react-icons/bs'
import QuoteForm from '../../components/user/QuoteForm';
import React, { useState } from 'react';

export default function Quote() {

  const [imgPreview, setImgPreview] = useState('https://static.thenounproject.com/png/4595376-200.png');

  return (
    <Container bg="#fbd9e2" maxW="full" mt={0} centerContent overflow="hidden">
      <Flex justifyContent="center" alignItems="center">
        <Box
          bg="#ed63a6"
          color="white"
          borderRadius="lg"
          m={{ sm: 4, md: 16, lg: 10 }}
          p={{ sm: 5, md: 5, lg: 16 }}>
          <Box p={4}>
            <Wrap spacing={{ base: 20, sm: 3, md: 5, lg: 20 }}>
              <WrapItem>
                <Box>
                  <Heading>Cotiza tu producto</Heading>
                  <Text mt={{ sm: 3, md: 3, lg: 5 }} color="gray.200">
                    Adjunta una foto del producto que deseas cotizar
                  </Text>
                  <Box py={{ base: 5, sm: 5, md: 8, lg: 10 }}>
                    <VStack pl={0} spacing={3} alignItems="flex-start">
                      <img src={imgPreview} alt="Vista previa" />
                    </VStack>
                  </Box>
                  <HStack
                    mt={{ lg: 10, md: 10 }}
                    spacing={5}
                    px={5}
                    alignItems="flex-start">
                    <IconButton
                      aria-label="instagram"
                      variant="ghost"
                      size="lg"
                      isRound={true}
                      onClick={() => window.open('https://www.instagram.com/divasonlinegt/')}
                      _hover={{ bg: '#0D74FF' }}
                      icon={<BsInstagram size="28px" />}
                    />
                    <IconButton
                      aria-label="tiktok"
                      variant="ghost"
                      size="lg"
                      isRound={true}
                      onClick={() => window.open('https://www.tiktok.com/@divasonlinegt?_t=8pRcsorZJwr&_r=1')}
                      _hover={{ bg: '#0D74FF' }}
                      icon={<BsTiktok size="28px" />}
                    />
                    <IconButton
                      aria-label="whatsapp"
                      variant="ghost"
                      size="lg"
                      isRound={true}
                      onClick={() => window.open('https://wa.me/50255702714?text=Hola! Me gustaría obtener más información sobre sus productos')}
                      _hover={{ bg: '#0D74FF' }}
                      icon={<BsWhatsapp size="28px" />}
                    />
                  </HStack>
                </Box>
              </WrapItem>
              <WrapItem>
                <Box bg="white" borderRadius="lg">
                  <QuoteForm change={setImgPreview} />
                </Box>
              </WrapItem>
            </Wrap>
          </Box>
        </Box>
      </Flex>
    </Container>
  )
}



import React from 'react';
import { Box, Text } from '@chakra-ui/react';
import OrderCard from '../../components/common/OrderCard';
import { getCartHistory } from '../../services/cartService';
import Loader from '../../components/common/Loader';

const History = () => {
  const [orders, setOrders] = React.useState([]);
  const [isLoading, setIsLoading] = React.useState(true);

  React.useEffect(() => {
    const fetch = async () => {
      const user = JSON.parse(localStorage.getItem('user'));
      const response = await getCartHistory(user.id);
      if (response.status === 200) {
        console.log(response.data.orders);
        setOrders(response.data.orders);
      }
      setIsLoading(false);
    }
    fetch();
  }, []);

  return (
    <Box maxW="800px" mx="auto" mt={8}>
      <Loader isLoading={isLoading} message="Cargando historial de pedidos..." />
      {!isLoading && (
        <>
          <Text fontSize="2xl" fontWeight="bold" mb={6}>Historial de Pedidos</Text>
          {orders && orders.length > 0 ? (
            orders.map((order, index) => (
              <OrderCard key={index} order={order} />
            ))
          ) : (
            <Text>No hay órdenes disponibles.</Text>
          )}
        </>
      )}
    </Box>
  );
};

export default History;


import Login from "../../components/common/Login";
import { login } from '../../services/authService';
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

const Auth = () => {

  const history = useNavigate();
  useEffect(() => {
    const token = JSON.parse(localStorage.getItem('token'));
    if (token) {
      history('/');
    }
  }, []);


  return (
    <Login title='Login' service={login} route='/' />
  )
}

export default Auth;

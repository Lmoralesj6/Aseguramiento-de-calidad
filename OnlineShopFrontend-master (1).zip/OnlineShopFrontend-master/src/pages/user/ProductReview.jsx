import { useParams } from "react-router-dom";
import {
  Box,
  Container,
  Stack,
  Text,
  Image,
  Flex,
  VStack,
  HStack,
  Button,
  Center,
  Icon,
  Heading,
  SimpleGrid,
  StackDivider,
  Input,
  useColorModeValue,
  List,
  ListItem,
} from '@chakra-ui/react'
import { MdLocalShipping } from 'react-icons/md'
import { useCart } from '../../hooks/CartContext';
import { useToast } from "@chakra-ui/react";
import { useState, useEffect } from "react";
import { getAll } from '../../services/productService';
import ProductSlider from "../../components/user/ProductSlider";
import StarRating from "../../components/user/StarRating";
import { IoIosSend } from "react-icons/io";
import ProductCommentsContainer from "../../components/user/ProductCommentsContainer";
import { getUrl } from "../../utils/productRender";
import { isLogged } from "../../utils/authChecker";
import { createReview } from "../../services/reviewService";
import { BsFillBookmarkFill } from "react-icons/bs";
import { useFavorites } from '../../hooks/FavoritesProvider';

const ProductReview = () => {
  const { id } = useParams();
  const toast = useToast();
  const [product, setProduct] = useState({});
  const [relationedProducts, setRelationedProducts] = useState([]);
  const [ratingChange, setRatingChange] = useState(false);
  const { dispatch } = useCart();
  const defaultImg = 'https://images.unsplash.com/photo-1494228766058-1430438d10fc?q=80&w=1473&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D';
  const empty_review = { product_id: 0, comment: '', rating: 0 };
  const [review, setReview] = useState(empty_review);
  const { favorites, addToFavorites, removeFromFavorites } = useFavorites();
  const [favorite, setFavorite] = useState(false);
  const user = JSON.parse(localStorage.getItem('user'));

  useEffect(() => {
    const fetch = async () => {
      const response = await getAll();
      if (response.data) {
        const product = response.data.products.find((item) => item.id == id);
        setProduct({ ...product, reviews: product.reviews.reverse() });
        setRelationedProducts(response.data.products.filter((item) => item.category_id === product.category_id));
      }
    };
    fetch();
  }, [id]);

  useEffect(() => {
    const isFavorite = favorites.some(fav => fav.id === product.id);
    setFavorite(isFavorite);
  }, [favorites, product.id]);

  const toggleFavorite = async () => {
    if (favorite) {
      await removeFromFavorites(product);
      toast({
        title: 'Favorito removido',
        description: 'Producto eliminado de tus favoritos',
        status: 'info',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right',
      });
    } else {
      await addToFavorites(product);
      toast({
        title: 'Añadido a favoritos',
        description: 'Producto agregado a tus favoritos',
        status: 'success',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right',
      });
    }
    setFavorite(!favorite);
  };

  const addToCart = () => {
    toast({
      title: 'Nuevo Producto',
      description: 'Producto agregado al carrito',
      status: 'success',
      duration: 3000,
      isClosable: true,
      position: 'bottom-right'
    });
    dispatch({ type: 'ADD', item: product });
  };

  const changeRatingStar = (val) => {
    setRatingChange(true);
    setReview(prev => ({ ...prev, rating: val }));
  };

  const sendReview = async () => {
    if (!isLogged()) {
      toast({
        title: 'Usuario sin sesión',
        description: 'Debe iniciar sesión para poder calificar el producto',
        status: 'warning',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right'
      });
    } else if (ratingChange && review.comment.length > 0) {
      await createReview(product.id, review.comment, review.rating);
      fetch();
      setReview(empty_review);
    } else {
      toast({
        title: 'Error al enviar calificación',
        description: 'Debe llenar todos los campos de la calificación',
        status: 'error',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right'
      });
    }
  };

  const reviewChange = (e) => {
    setReview(prev => ({ ...prev, comment: e.target.value }));
  };

  return (
    <div>
      <Container maxW={'7xl'}>
        <SimpleGrid
          columns={{ base: 1, lg: 2 }}
          spacing={{ base: 8, md: 10 }}
          py={{ base: 18, md: 24 }}>
          <Flex direction={'column'} display={'flex'} >
            <Image
              rounded={'md'}
              alt={'product image'}
              src={product.images ? getUrl(product.images) : defaultImg}
              fit={'cover'}
              align={'center'}
              w={'100%'}
              h={{ base: '100%', sm: '400px', lg: '500px' }}
            />
            <Box w="100%" height="45%" p="4vw" mt={4} borderRadius={6} position="relative">
              <Flex direction="column" height="100%">
                {product.reviews && <ProductCommentsContainer reviews={product.reviews} />}
                <Box
                  w="100%"
                  height="10vh"
                  position="absolute"
                  bottom="0"
                  left="0"
                >
                  <Stack direction={'row'} p={2}>
                    <Input
                      placeholder="Me gusta este prod..."
                      border={'none'}
                      background={'gray.300'}
                      value={review.comment}
                      onChange={reviewChange}
                    />
                    <Button bg={"gray.300"} _hover={{ bg: 'gray.500', color: 'white' }} onClick={sendReview}><IoIosSend /></Button>
                  </Stack>
                  <Center>
                    <Stack direction={'column'} alignItems='center'>
                      <StarRating onChange={changeRatingStar} />
                      {ratingChange && review.comment.length < 1 && (
                        <Text fontSize='xs' color='gray.400'>Escriba una reseña para guardar su calificación</Text>
                      )}
                    </Stack>
                  </Center>
                </Box>
              </Flex>
            </Box>
          </Flex>
          <Stack spacing={{ base: 6, md: 10 }}>
            <Box as={'header'}>
              <Heading
                lineHeight={1.1}
                fontWeight={600}
                fontSize={{ base: '2xl', sm: '4xl', lg: '5xl' }}>
                {product.name}
              </Heading>
              <Text
                color={useColorModeValue('gray.900', 'gray.400')}
                fontWeight={300}
                fontSize={'2xl'}>
                {product.price}
              </Text>
            </Box>

            <HStack justifyContent="space-between" w="100%">
              {user && (
                <Icon
                  as={BsFillBookmarkFill}
                  fontSize="3rem"
                  mt={8}
                  color={favorite ? 'yellow.500' : 'gray.300'}
                  onClick={toggleFavorite}
                  _hover={{ color: 'yellow.500', cursor: 'pointer' }}
                />
              )}
              <Button
                rounded="none"
                mt={8}
                size="lg"
                py="7"
                w="90%"
                bg={useColorModeValue('gray.900', 'gray.50')}
                color={useColorModeValue('white', 'gray.900')}
                onClick={addToCart}
                textTransform="uppercase"
                _hover={{
                  transform: 'translateY(2px)',
                  boxShadow: 'lg',
                }}
              >
                Agregar al carrito
              </Button>
            </HStack>

            <Stack direction="row" alignItems="center" justifyContent={'center'}>
              <MdLocalShipping />
              <Text>2-3 días habiles de entrega</Text>
            </Stack>
          </Stack>
        </SimpleGrid>
      </Container>
      {relationedProducts && relationedProducts.length > 0 && (
        <ProductSlider prds={relationedProducts} />
      )}
    </div>
  );
}

export default ProductReview;

import Auth from "../pages/admin/auth";
import Registro from '../pages/admin/register.jsx';
import ProductsManagment from "../pages/admin/ProductsManagment";
import ProductView from "../pages/admin/ProductView";
import Dashboard from "../pages/admin/Dashboard";
import CategoriesManagement from "../pages/admin/CategoriesManagement";
import CategoryView from "../pages/admin/CategoryView";
import UserView from "../pages/admin/UserView";
import ProductEditor from "../components/admin/ProductEditor";
import CategoryEditor from "../components/admin/CategoryEditor";
import OrderView from "../pages/admin/OrderView";
import ReportView from "../pages/admin/ReportView";
import ContactView from "../pages/admin/ContactView.jsx";
import QuoteView from "../pages/admin/QuoteView.jsx";

const adminRoutes = [
  { path: '/admin/dashboard', component: Dashboard },
  { path: '/admin/registro', component: Registro },
  { path: '/admin/producto/nuevo', component: ProductsManagment },
  { path: '/admin/producto/visualizar', component: ProductView },
  { path: '/admin/producto/editar/:id', component: ProductEditor },
  { path: '/admin/categoria/nuevo', component: CategoriesManagement },
  { path: '/admin/categoria/visualizar', component: CategoryView },
  { path: '/admin/categoria/editar/:id', component: CategoryEditor },
  { path: '/admin/usuario/visualizar', component: UserView },
  { path: '/admin/pedidos/visualizar', component: OrderView },
  { path: '/admin/reports/visualizar', component: ReportView },
  { path: '/admin/contactos/visualizar', component: ContactView },
  { path: '/admin/cotizaciones/visualizar', component: QuoteView },
];



export default adminRoutes;

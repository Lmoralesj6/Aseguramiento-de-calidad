import { Suspense } from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import adminRoutes from "./adminRoutes";
import userRoutes from "./userRoutes";
import Home from "../pages/home";
import Layout from "../components/common/Layout";
import useScroll from "../hooks/useScroll";
import { Navigate } from "react-router-dom";
import AdminLayout from "../components/common/AdminLayout";
import Auth from "../pages/admin/auth";

const Loader = () => {
  return (
    <div>
      <p>Hola mundo</p>
    </div>
  );
};

const RouterManager = () => {
  return (
    <BrowserRouter>
      <Suspense fallback={<Loader />}>
        <ScrollManager>
          <Routes>
            <Route
              path={'/admin'}
              element={
                <Auth />
              }
            />
            {adminRoutes.map((entry) => (
              <Route
                key={entry.path}
                path={entry.path}
                element={
                  <AdminLayout>
                    <entry.component />
                  </AdminLayout>
                }
              />
            ))}
            {userRoutes.map((entry) => (
              <Route
                key={entry.path}
                path={entry.path}
                element={<Layout Page={entry.component} />}
              />
            ))}
            <Route path="/" element={<Layout Page={Home} />} />
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </ScrollManager>
      </Suspense>
    </BrowserRouter>
  );
};

const ScrollManager = ({ children }) => {
  useScroll();
  return children;
};

export default RouterManager;

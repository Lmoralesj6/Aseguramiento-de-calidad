import Auth from "../pages/user/auth";
import Contact from "../pages/user/Contact";
import PaymentCart from "../pages/user/PaymentCart";
import ProductReview from "../pages/user/ProductReview";
import Products from "../pages/user/Products";
import History from "../pages/user/History";
import Registro from '../pages/admin/register.jsx';
import Quote from "../pages/user/Quote";
import Favorites from "../pages/user/Favorites";
import ProductsGrid from "../pages/user/ProductsGrid";


const userRoutes = [
  { path: "/login", component: Auth },
  { path: "/carrito", component: PaymentCart },
  { path: "/Producto/:id", component: ProductReview },
  { path: "/Contacto/", component: Contact },
  { path: "/Productos/:id/", component: Products },
  { path: "/Productos/Todos/", component: ProductsGrid },
  { path: "/Pedidos/", component: History },
  { path: "/registro/", component: Registro },
  { path: "/Cotizar/", component: Quote },
  { path: "/Favoritos/", component: Favorites },
];

export default userRoutes;

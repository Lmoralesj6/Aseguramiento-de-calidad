
export const local_url = 'localhost:8000/api';
export const cloud_url = 'https://onlineshopbackend-56fe21385147.herokuapp.com/api';


export const cloud_url_img = 'https://onlineshopbackend-56fe21385147.herokuapp.com'


export const img_url = cloud_url_img;
export const api_url = cloud_url;

export const ADMIN_ROLE = 1;









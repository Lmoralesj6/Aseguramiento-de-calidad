const ContentSection = ({ children, cstyle }) => {

  return (
    <div className={`row content-section ${cstyle}`} >
      {children}
    </div >
  )
};

export default ContentSection;

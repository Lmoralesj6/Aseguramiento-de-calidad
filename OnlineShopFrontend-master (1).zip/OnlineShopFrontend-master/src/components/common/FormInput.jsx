import { FormLabel } from "@chakra-ui/react";
const FormInput = ({ name, handleChange, label, type = "text", error = '', rdonly = false, color = 'pink' }) => {


  const status = error.length == 0;
  const classes = `form-control mt-2 ${status ? 'input-success' : 'input-error'}`;



  return (
    <div className="form-group form-input">
      <FormLabel className="form-label-input" color={'pink.400'} fontWeight='bold'>{label}</FormLabel>
      <input type={type} name={name} className={classes} onChange={handleChange} readOnly={rdonly} />
      {status == false ? (
        <p className="form-error">{error}</p>
      ) : ''}
    </div>

  )
}

export default FormInput;


import React from 'react';
import { Box, Flex, Image, Text, Badge, VStack } from '@chakra-ui/react';

const OrderCard = ({ order }) => {
  return (
    <Flex
      borderWidth="1px"
      borderRadius="lg"
      overflow="hidden"
      p={4}
      alignItems="flex-start"
      justifyContent="space-between"
      mb={4}
      direction="column"
    >
      <Text fontWeight="bold" fontSize="lg" mb={2}>Pedido #{order.id}</Text>
      <Text color="gray.500" fontSize="sm" mb={4}>{new Date(order.created_at).toLocaleDateString()}</Text>
      <Badge mb={4} colorScheme={
        order.status === 'finished' ? 'green' :
          order.status === 'pending' ? 'yellow' :
            'red'
      }>
        {order.status}
      </Badge>

      <VStack align="start" spacing={4} w="100%">
        {order.items.map((item, index) => (
          <Flex key={index} w="100%" justify="space-between">
            <Flex>
              {/* Mostrar la imagen del producto si está disponible */}
              <Image
                src={
                  item.product.images && item.product.images.length > 0
                    ? `http://localhost:8000${item.product.images[0].image_path}`
                    : 'https://via.placeholder.com/150'
                }
                alt={`Imagen de ${item.product.name}`}
                boxSize="100px"
                objectFit="cover"
                borderRadius="md"
              />
              <Box ml={4}>
                <Text fontWeight="bold">{item.product.name}</Text>
                <Text color="gray.500">{item.product.description}</Text>
                <Text color="gray.700">Q {parseFloat(item.product.price).toFixed(2)}</Text>
              </Box>
            </Flex>
            <Text fontWeight="bold">Cantidad: {item.quantity}</Text>
          </Flex>
        ))}
      </VStack>
    </Flex>
  );
};

export default OrderCard;


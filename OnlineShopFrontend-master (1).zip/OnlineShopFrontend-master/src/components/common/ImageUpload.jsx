import React, { useState } from 'react';
import { Box, Button, Image, Text } from '@chakra-ui/react';

const ImageUpload = ({ onImageUpload, hidden = false }) => {
  const [preview, setPreview] = useState(null);

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setPreview(URL.createObjectURL(file));
      onImageUpload(file);
    }
  };

  return (
    <Box>
      <Button
        as="label"
        htmlFor="imageUpload"
        bg="pink.900"
        color="white"
        _hover={{ bg: "blue.700" }}
        cursor="pointer"
        mb={4}
      >
        Seleccionar Imagen
      </Button>
      <input
        id="imageUpload"
        type="file"
        accept="image/*"
        onChange={handleImageChange}
        style={{ display: 'none' }}
      />
      {preview && !hidden ? (
        <Box mt={4}>
          <Text mb={2}>Previsualización de la imagen:</Text>
          <Image src={preview} alt="Previsualización" maxW="300px" />
        </Box>
      ) : ''}
    </Box>
  );
};

export default ImageUpload;

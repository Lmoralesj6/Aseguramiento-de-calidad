import React, { useEffect, useState } from 'react';
import useAuthToken from '../../hooks/useAuth';
import { Navigate } from 'react-router-dom';

function AuthGuard({ children }) {
  const token = useAuthToken();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (token !== null) {
      setLoading(false);
      console.log('Token found:', token);
    } else {
      console.log('Token not found, redirecting...');
    }
  }, [token]);

  if (loading) {
    return <div>Cargando...</div>;
  }

  if (!token) {
    return <Navigate to="/admin" replace />;
  }

  return (
    <>
      {children}
    </>
  );
}

export default AuthGuard;


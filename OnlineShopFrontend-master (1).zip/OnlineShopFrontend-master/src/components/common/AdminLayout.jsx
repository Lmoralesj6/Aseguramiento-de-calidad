
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import AdminNav from "../admin/AdminNav";
import Sidebar from "../admin/Sidebar";
import { Flex, Box } from "@chakra-ui/react";
import { isAdmin } from "../../utils/authChecker";
import Loader from "../common/Loader";

const AdminLayout = ({ children }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isLogged, setIsLogged] = useState(false);
  const [isChecking, setIsChecking] = useState(true);
  const history = useNavigate();

  useEffect(() => {
    const token = JSON.parse(localStorage.getItem("token"));
    const user = JSON.parse(localStorage.getItem("user"));
    if (!token || !user || !isAdmin(user.roles)) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      history("/admin");
      setIsLogged(false);
      setIsChecking(false);
    } else {
      setIsLogged(true);
      setIsChecking(false);
    }
  }, [history]);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <>
      <Loader isLoading={isChecking} message="Verificando autenticación..." />
      {!isChecking && isLogged && (
        <Flex>
          {isSidebarOpen && (
            <Box w="250px" h="100vh" position="fixed">
              <Sidebar toggleSidebar={toggleSidebar} />
            </Box>
          )}

          <Box
            flex="1"
            ml={isSidebarOpen ? "250px" : "0"}
            p={4}
            bg="gray.50"
            minH="100vh"
            transition="margin-left 0.3s ease"
          >
            <AdminNav toggleSidebar={toggleSidebar} isSidebarOpen={isSidebarOpen} />
            {children}
          </Box>
        </Flex>
      )}
    </>
  );
};

export default AdminLayout;


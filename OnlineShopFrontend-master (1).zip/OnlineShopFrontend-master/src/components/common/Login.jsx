import '../../assets/styles/common/login.css';
import { useNavigate } from 'react-router-dom';
import FormInput from '../../components/common/FormInput';
import useForm from '../../hooks/useForm';
import { useEffect } from 'react';
import { Box, Button, Card, Heading, Flex, useToast, Link } from '@chakra-ui/react';
import { isLogged, isAdmin } from '../../utils/authChecker';

const Login = ({ title, service, route, _type = 'public' }) => {
  const history = useNavigate();
  const toast = useToast();
  const initialUserState = { email: '', password: '' };

  useEffect(() => {
    if (isLogged()) {
      history(route);
    }
  }, []);

  const {
    formData: user,
    handleChange,
    handleSubmit,
    getError,
  } = useForm(initialUserState, service);


  const handleLogin = async () => {
    const data = await handleSubmit();
    if (data) {
      console.log(data.roles);
      const { access_token, user } = data;
      const token = access_token.split('|')[1];
      if (!isAdmin(data.roles) && _type === 'private') {
        toast({
          title: 'Error',
          description: 'No tiene permisos de administrador',
          status: 'error',
          duration: 3000,
          isClosable: true,
          position: 'bottom-right'
        });
        return;
      }
      localStorage.setItem('token', JSON.stringify(token));
      localStorage.setItem('user', JSON.stringify({ ...user, roles: data.roles }));
      toast({
        title: 'Éxito',
        description: 'Usuario logueado correctamente',
        status: 'success',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right'
      });

      location.reload();

    } else {
      toast({
        title: 'Error',
        description: 'Error al iniciar sesión',
        status: 'error',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right'
      });
    }
  };


  return (
    <div className="container login-container">
      <Flex justify="center" >
        <Box w={{ base: '100%', md: '40%' }} className="login-card">
          <Card p={8} boxShadow="lg" borderRadius="md" className='box' bg='transparent' border={'none'} >
            <Heading as="h2" color={'pink.500'} size="md" textAlign="center" className="login-title">
              {title}
            </Heading>
            <FormInput name="email" handleChange={handleChange} label='Correo' error={getError('email')} />
            <FormInput name="password" type="password" handleChange={handleChange} label='Contraseña' error={getError('password')} />
            <Link href="/recuperar-contrasena" mt={2} float='right' textAlign='right' color='pink.900' fontSize={12} textDecoration='underline' _hover={{ color: 'pink.500' }} >Olvidé mi contraseña</Link>
            <Flex mt={4} justify="space-between">
              <Button onClick={handleLogin} colorScheme="pink" w="48%">
                Entrar
              </Button>
              <Button onClick={() => history('/registro')} colorScheme="pink" variant="outline" w="48%">
                Registro
              </Button>
            </Flex>
          </Card>
        </Box>
      </Flex>
    </div>
  );
};

export default Login;

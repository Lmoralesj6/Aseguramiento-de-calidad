import Navbar from "./Navbar";
import Footer from "./Footer";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { FavoritesProvider } from "../../hooks/FavoritesProvider";

const Layout = ({ Page }) => {
  const history = useNavigate();
  const [isLogged, setIsLogged] = useState(false);

  useEffect(() => { }, []);

  return (
    <div>
      <FavoritesProvider>
        <Navbar />
        {<Page />}
        <Footer />
      </FavoritesProvider>
    </div>
  );
};

export default Layout;

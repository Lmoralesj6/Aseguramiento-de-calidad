
import React from 'react';
import { Button, Spinner } from "@chakra-ui/react";

const LoadingButton = ({ isLoading, children, ...props }) => {
  return (
    <Button
      isDisabled={isLoading}
      {...props}
    >
      {isLoading ? <Spinner size="sm" color="white" /> : children}
    </Button>
  );
};

export default LoadingButton;

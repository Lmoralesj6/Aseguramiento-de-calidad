import {
  Box,
  Flex,
  Text,
  IconButton,
  Button,
  Stack,
  Collapse,
  Icon,
  Menu,
  MenuButton,
  MenuList,
  Avatar,
  Center,
  MenuDivider,
  MenuItem,
  Popover,
  PopoverTrigger,
  PopoverContent,
  useColorModeValue,
  useDisclosure,
} from '@chakra-ui/react'
import {
  HamburgerIcon,
  CloseIcon,
  ChevronDownIcon,
  ChevronRightIcon,
} from '@chakra-ui/icons'
import { useCart } from '../../hooks/CartContext';
import { FiShoppingCart } from 'react-icons/fi'
import { useNavigate } from 'react-router-dom';
import { getAllCategories } from '../../services/productService';
import { logout } from '../../services/authService';
import { useState, useEffect } from 'react';
import { useToast } from '@chakra-ui/react';
import logo from '../../assets/images/DIVAS_LOGO.png';

const Navbar = () => {
  const { isOpen, onToggle } = useDisclosure()
  const history = useNavigate();
  const { cart } = useCart();
  const [categories, setCategories] = useState([]);
  const [isAuth, setIsAuth] = useState(false);
  const toast = useToast();
  const default_profile = 'https://images.unsplash.com/photo-1493666438817-866a91353ca9?ixlib=rb-0.3.5&q=80&fm=jpg&crop=faces&fit=crop&h=200&w=200&s=b616b2c5b373a80ffc9636ba24f7a4a9';
  const user = JSON.parse(localStorage.getItem('user'));



  const fetchCats = async () => {
    const response = await getAllCategories();
    if (response.data) {
      const updatedCategories = [...response.data.categories, { id: 'Todos', name: 'Todos', description: 'Todos los productos' }];
      setCategories(updatedCategories);
    }
  };

  const closeSession = async () => {
    const response = await logout();
    if (response.status === 200) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      history('/');
      setIsAuth(false);
      toast({
        title: 'Sesion Cerrada',
        description: 'Se ha cerrado correctamente la sesion',
        status: 'success',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right'
      });
    }
    else {
      console.log(response);
      toast({
        title: 'Error',
        description: 'Error al cerrar la sesion',
        status: 'error',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right'
      });
    }

  }



  useEffect(() => {
    fetchCats();
    const token = JSON.parse(localStorage.getItem('token'));
    if (token) setIsAuth(true);
  }, []);

  return (
    <Box>
      <Flex
        bg={useColorModeValue('white', 'gray.800')}
        color={useColorModeValue('gray.600', 'white')}
        minH={'60px'}
        py={{ base: 2 }}
        px={{ base: 4 }}
        position='relative'
        borderBottom={1}
        borderStyle={'solid'}
        borderColor={useColorModeValue('gray.200', 'gray.900')}
        align={'center'}
        justify={'space-between'}>

        <Flex
          flex={{ base: 1, md: 'auto' }}
          ml={{ base: -2 }}
          display={{ base: 'flex', md: 'none' }}>
          <IconButton
            onClick={onToggle}
            icon={isOpen ? <CloseIcon w={3} h={3} /> : <HamburgerIcon w={5} h={5} />}
            variant={'ghost'}
            aria-label={'Toggle Navigation'}
          />
        </Flex>
        <img src={logo} alt="" style={{ width: '4rem', position: 'absolute', height: '100%' }} />

        <Flex flex={{ base: 1 }} justify={{ base: 'center', md: 'start' }} paddingLeft={8} className='flexxx' display='flex' alignItems='center'>
          <Flex display={{ base: 'none', md: 'flex' }} ml={10}>
            <DesktopNav categories={categories} />
          </Flex>
        </Flex>

        <Stack
          flex={{ base: 2, md: 0 }}
          justify={'flex-end'}
          direction={'row'}
          spacing={6}>

          {isAuth === false ? (
            <Button
              as={'a'}
              display={{ base: 'none', md: 'inline-flex' }}
              fontSize={'sm'}
              fontWeight={600}
              color={'white'}
              bg={'pink.400'}
              href={'/registro'}
              _hover={{
                bg: 'pink.300',
              }}>
              Registrarme
            </Button>
          ) : ''
          }

          {isAuth === false ? (
            <Button as={'a'} fontSize={'sm'} fontWeight={400} variant={'link'} href={'/login'}
              display={{ base: 'none', md: 'inline-flex' }}
            >
              Entrar
            </Button>

          ) : (
            <Menu className="profile-menu" >
              <MenuButton
                as={Button}
                rounded={'full'}
                variant={'link'}
                cursor={'pointer'}
                minW={0}>
                <Avatar
                  size={'sm'}
                  src={default_profile}
                />
              </MenuButton>
              <MenuList alignItems={'center'}>
                <br />
                <Center>
                  <Avatar
                    size={'2xl'}
                    src={default_profile}
                  />
                </Center>
                <br />
                <Center>
                  <p>{user.name}</p>
                </Center>
                <br />
                <MenuDivider />
                <MenuItem onClick={() => history('/Pedidos')}>Tus Pedidos</MenuItem>
                <MenuItem onClick={() => history('/Favoritos')}>Tus Favoritos</MenuItem>
                <MenuItem >Configuracion</MenuItem>
                <MenuItem onClick={closeSession} >Salir</MenuItem>
              </MenuList>
            </Menu>
          )
          }

          <Button
            as={'a'}
            display={{ base: 'inline-flex', md: 'inline-flex' }}
            fontSize={'sm'}
            fontWeight={600}
            color={'pink.700'}
            bg={'pink.100'}
            onClick={() => history('/carrito')}
            _hover={{
              bg: 'pink.200',
            }}>
            <FiShoppingCart />
            <b className='ms-2'>
              {cart.length}
            </b>
          </Button>
        </Stack>




      </Flex>

      <Collapse in={isOpen} animateOpacity>
        <MobileNav categories={categories} />
      </Collapse>
    </Box >
  )
}

const DesktopNav = ({ categories }) => {
  const linkColor = useColorModeValue('gray.600', 'gray.200')
  const linkHoverColor = useColorModeValue('gray.800', 'white')
  const popoverContentBgColor = useColorModeValue('white', 'gray.800')

  return (
    <Stack direction={'row'} spacing={4} >
      {NAV_ITEMS.map((navItem) => (
        <Box key={navItem.label} display='flex' alignItems='center'>
          <Popover trigger={'hover'} placement={'bottom-start'}>
            <PopoverTrigger>
              <Box
                as="a"
                paddingInline={2}
                href={navItem.href ?? '#'}
                fontSize={'sm'}
                fontWeight={500}
                color={linkColor}
                _hover={{
                  textDecoration: 'none',
                  color: linkHoverColor,
                }}>
                {navItem.label}
              </Box>
            </PopoverTrigger>

            {navItem.category && (
              <PopoverContent
                border={0}
                boxShadow={'xl'}
                bg={popoverContentBgColor}
                p={0}
                rounded={'xl'}
                minW={'sm'}>
                <Stack>
                  {
                    categories.map((item) => (
                      <DesktopSubNav key={item.id} label={item.name} href={`/Productos/${item.id}`} subLabel={item.description} />
                    ))
                  }
                </Stack>
              </PopoverContent>
            )}
          </Popover>
        </Box>
      ))}
    </Stack>
  )
}

const DesktopSubNav = ({ label, href, subLabel }) => {
  return (
    <Box
      as="a"
      href={href}
      role={'group'}
      display={'block'}
      p={2}
      rounded={'md'}
      _hover={{ bg: useColorModeValue('pink.50', 'gray.900') }}>
      <Stack direction={'row'} align={'center'}>
        <Box>
          <Text
            transition={'all .3s ease'}
            _groupHover={{ color: 'pink.400' }}
            marginBottom={0}
            fontWeight={500}>
            {label}
          </Text>
          <Text fontSize={'sm'} marginBottom={0}>{subLabel}</Text>
        </Box>
        <Flex
          transition={'all .3s ease'}
          transform={'translateX(-10px)'}
          opacity={0}
          _groupHover={{ opacity: '100%', transform: 'translateX(0)' }}
          justify={'flex-end'}
          align={'center'}
          flex={1}>
          <Icon color={'pink.400'} w={5} h={5} as={ChevronRightIcon} />
        </Flex>
      </Stack>
    </Box>
  );
};

const MobileNav = ({ categories }) => {
  return (
    <Stack bg={useColorModeValue('white', 'gray.800')} p={4} display={{ md: 'none' }}>
      {NAV_ITEMS.map((navItem) => (
        <MobileNavItem key={navItem.label} {...navItem} />
      ))}
    </Stack>
  )
}

const MobileNavItem = ({ label, children, href }) => {
  const { isOpen, onToggle } = useDisclosure()

  return (
    <Stack spacing={4} onClick={children && onToggle}>
      <Box
        py={2}
        as="a"
        href={href ?? '#'}
        justifyContent="space-between"
        alignItems="center"
        _hover={{
          textDecoration: 'none',
        }}>
        <Text fontWeight={600} color={useColorModeValue('gray.600', 'gray.200')}>
          {label}
        </Text>
        {children && (
          <Icon
            as={ChevronDownIcon}
            transition={'all .25s ease-in-out'}
            transform={isOpen ? 'rotate(180deg)' : ''}
            w={6}
            h={6}
          />
        )}
      </Box>

      <Collapse in={isOpen} animateOpacity style={{ marginTop: '0!important' }}>
        <Stack
          mt={2}
          pl={4}
          borderLeft={1}
          borderStyle={'solid'}
          borderColor={useColorModeValue('gray.200', 'gray.700')}
          align={'start'}>
          {children &&
            children.map((child) => (
              <Box as="a" key={child.label} py={2} href={child.href}>
                {child.label}
              </Box>
            ))}
        </Stack>
      </Collapse>
    </Stack>
  )
}


const NAV_ITEMS = [
  {
    label: 'Inicio',
    href: '/'
  },
  {
    label: 'Productos',
    category: [

    ]
  },
  {
    label: 'Contacto',
    href: '/Contacto',
  },
  {
    label: 'Cotizar',
    href: '/Cotizar',
  }
]


export default Navbar;


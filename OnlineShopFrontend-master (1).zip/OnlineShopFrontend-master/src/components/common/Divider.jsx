
const Divider = ({ children }) => {
  if (children) {
    return (
      <section className="section-divider">
        <div className="skewed">{children}</div>
      </section>
    )
  }
  return (
    <section className="section-divider">
      <div className="skewed"></div>
    </section>
  )
}

export default Divider;

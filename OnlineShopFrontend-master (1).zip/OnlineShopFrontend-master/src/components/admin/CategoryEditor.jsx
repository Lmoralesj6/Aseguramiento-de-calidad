import { useParams } from "react-router-dom";
import React from "react";
import { getAllCategories, updateCategory } from "../../services/categoryService"; // Cambiar a servicio de categorías
import {
  Box,
  Input,
  FormLabel,
  Card,
  CardBody,
  FormControl,
  Textarea,
  Button,
  useToast,
  Stack,
} from "@chakra-ui/react";

const CategoryUpdater = () => {
  const { id } = useParams();
  const empty = { id: 0, name: '', description: '' };
  const [category, setCategory] = React.useState(empty);
  const toast = useToast();

  const fetchCategory = async () => {
    const response = await getAllCategories(); // Usar el servicio de categorías
    if (response.status === 200) {
      const { categories } = response.data;
      const cat = categories.filter((item) => item.id == id)[0];
      setCategory(cat);
    }
  };

  React.useEffect(() => {
    fetchCategory();
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setCategory({ ...category, [name]: value });
  };

  const handleUpdateCategory = async () => {
    const response = await updateCategory({ id: category.id, name: category.name, description: category.description });
    if (response.status == 200) {
      toast({
        title: 'Acción realizada',
        description: 'Categoría actualizada correctamente',
        status: 'success',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right'
      });
      return;
    }
    console.log(response);
    toast({
      title: 'Acción abortada',
      description: 'Error al actualizar la categoría',
      status: 'error',
      duration: 3000,
      isClosable: true,
      position: 'bottom-right'
    });
  };

  return (
    <Box
      minH="80vh"
      display="flex"
      justifyContent="center"
      alignItems="center"
      p={4}
    >
      <Card p={6} maxW="lg" width="100%" boxShadow="xl" bg="white" rounded="lg">
        <CardBody>
          <h4>Actualizar Categoría</h4>
          <hr style={{ color: '#d69e2e' }} />
          <Stack spacing={6}>
            <FormControl>
              <FormLabel>Nombre</FormLabel>
              <Input
                type="text"
                name="name"
                value={category.name}
                onChange={handleInputChange}
              />
            </FormControl>
            <FormControl>
              <FormLabel>Descripción</FormLabel>
              <Textarea
                name="description"
                value={category.description}
                onChange={handleInputChange}
              />
            </FormControl>
            <Button colorScheme="yellow" color='white' onClick={handleUpdateCategory}>
              Actualizar
            </Button>
          </Stack>
        </CardBody>
      </Card>
    </Box>
  );
};

export default CategoryUpdater;

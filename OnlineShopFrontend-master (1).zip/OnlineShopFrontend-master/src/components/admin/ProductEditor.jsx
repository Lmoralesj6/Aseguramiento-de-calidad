
import { useParams } from "react-router-dom";
import React from "react";
import { getAll, updateProduct } from "../../services/productService";
import { getAllCategories } from "../../services/productService";
import ProductCard from "../user/ProductCard";
import {
  Box,
  Input,
  FormLabel,
  Card,
  CardBody,
  FormControl,
  Textarea,
  NumberInput,
  NumberInputField,
  Button,
  useToast,
  Stack,
} from "@chakra-ui/react";

const ProductEditor = () => {
  const { id } = useParams();
  const empty = { id: 0, name: '', reviews: [], images: [], description: '', category_id: 0, price: '', img: '' };
  const [product, setProduct] = React.useState(empty);
  const [categories, setCategories] = React.useState([]);
  const toast = useToast();

  const fetch = async () => {
    const response = await getAll();
    if (response.status === 200) {
      const { products } = response.data;
      const prd = products.filter((item) => item.id == id)[0];
      setProduct({ ...prd, price_old: parseFloat(prd.price) + (parseFloat(prd.price) * 0.15) });
    }
  };

  const fetchCats = async () => {
    const response = await getAllCategories();
    if (response.status === 200) {
      const { categories } = response.data;
      setCategories(categories);
    }
  }

  React.useEffect(() => {
    fetch();
    fetchCats();
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    var new_obj = { ...product, [name]: value };
    var new_obj_price = { ...new_obj, price_old: parseFloat(new_obj.price) + (parseFloat(new_obj.price) * 0.15) };
    setProduct(new_obj_price);
  };

  const handleUpdateProduct = async () => {
    const response = await updateProduct({ id: product.id, name: product.name, description: product.description, price: product.price, category_id: product.category_id });
    if (response.status == 200) {
      toast({
        title: 'Acción realizada',
        description: 'Producto actualizado correctamente',
        status: 'success',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right'
      });
      return;
    }
    console.log(response);
    toast({
      title: 'Acción abortada',
      description: 'Error al actualizar el producto',
      status: 'error',
      duration: 3000,
      isClosable: true,
      position: 'bottom-right'
    });
  };

  return (
    <div className="mt-4">
      <div className="container">
        <div className="row">
          <div className="col-md-6">
            <Card p={4}>
              <CardBody>
                <h4>Actualizar Producto</h4>
                <hr style={{ color: '#d69e2e' }} />
                <Stack spacing={4}>
                  <FormControl>
                    <FormLabel>Nombre</FormLabel>
                    <Input
                      type="text"
                      name="name"
                      value={product.name}
                      onChange={handleInputChange}
                    />
                  </FormControl>
                  <FormControl>
                    <FormLabel>Descripción</FormLabel>
                    <Textarea
                      name="description"
                      value={product.description}
                      onChange={handleInputChange}
                    />
                  </FormControl>
                  <FormControl>
                    <FormLabel>Precio</FormLabel>
                    <NumberInput value={product.price}>
                      <NumberInputField
                        name="price"
                        onChange={handleInputChange}
                      />
                    </NumberInput>
                  </FormControl>
                  <FormControl>
                    <FormLabel>Categoría</FormLabel>
                    <select name="category_id" className="form-select">
                      {categories &&
                        categories.map((item, index) => (
                          <option key={index} value={item.id}>{item.name}</option>
                        ))

                      }
                    </select>
                  </FormControl>
                  <Button colorScheme="yellow" color='white' onClick={handleUpdateProduct}>
                    Actualizar
                  </Button>
                </Stack>
              </CardBody>
            </Card>
          </div>
          <div className="col-md-6">
            {product && <ProductCard Product={product} />}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductEditor;


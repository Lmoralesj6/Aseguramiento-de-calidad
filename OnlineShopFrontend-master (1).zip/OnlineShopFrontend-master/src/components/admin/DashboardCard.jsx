import { Box } from "@chakra-ui/react";
import { useNavigate } from "react-router-dom";


const DashboardCard = ({ Icon, title, route }) => {


  const history = useNavigate();

  return (
    <div>
      <Box
        _hover={{ cursor: 'pointer', boxShadow: 'md' }}
        onClick={() => history('/admin/products')}
        boxShadow='lg' p='6' rounded='md' bg='white' display='flex' justifyContent='center' alignContent='center' alignItems='center' >
        <Icon />
        {title}
      </Box>
    </div>
  )
}

export default DashboardCard;


import React, { useState, useEffect } from 'react';
import {
  Box,
  Button,
  FormControl,
  FormLabel,
  Input,
  Select,
  Textarea,
  Text,
  Image,
  Progress,
  useToast,
  Spinner,
} from '@chakra-ui/react';
import { getAllCategories, createProduct } from '../../services/productService';
import ProductCard from '../user/ProductCard';
import { useNavigate } from 'react-router-dom';

const ProductCreator = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    category_id: 3,
    name: '',
    description: '',
    price: '',
    image: null,
    imagePreviewUrl: null,
  });
  const toast = useToast();
  const [categories, setCategories] = useState([]);

  const progress = (step / 3) * 100;

  const handleChange = (e) => {
    setFormData((prevData) => ({
      ...prevData,
      [e.target.name]: e.target.value,
    }));
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    const imagePreviewUrl = URL.createObjectURL(file);

    setFormData((prevData) => ({
      ...prevData,
      image: file,
      imagePreviewUrl,
    }));
  };

  const handleNextStep = () => {
    setStep((prevStep) => prevStep + 1);
  };

  const handlePrevStep = () => {
    setStep((prevStep) => prevStep - 1);
  };

  const checkEmptyOrNullFields = () => {
    return Object.entries(formData).filter(([key, value]) => value === null || value === '');
  };

  const hasErrors = () => {
    const emptyFields = checkEmptyOrNullFields();
    if (emptyFields.length > 0) {
      const msg = (
        <Box>
          {emptyFields.map(([field], index) => (
            <Text key={index}>
              El campo <Box as="b">{field.charAt(0).toUpperCase() + field.slice(1)}</Box> está vacío o es nulo.
            </Text>
          ))}
        </Box>
      );

      toast({
        title: 'Campos vacíos o nulos',
        description: msg,
        status: 'error',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right',
      });
      return true;
    }
    return false;
  };

  const convertImageToBase64 = (image) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(image);
      reader.onload = () => resolve(reader.result);
      reader.onerror = (error) => reject(error);
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (hasErrors() || loading) return;

    setLoading(true);

    try {
      const base64Image = await convertImageToBase64(formData.image);
      const newProduct = {
        ...formData,
        images: [base64Image],
      };

      const response = await createProduct(newProduct);
      console.log(response)
      if (response.status === 200) {
        toast({
          title: 'Producto creado correctamente',
          description: 'Todos los campos están llenos.',
          status: 'success',
          duration: 3000,
          isClosable: true,
          position: 'bottom-right',
        });
        navigate('/admin/dashboard');
      }
    } catch (error) {
      console.error('Error al convertir la imagen:', error);

      toast({
        title: 'Error',
        description: 'Hubo un problema al procesar la imagen.',
        status: 'error',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right',
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchCategories = async () => {
    const response = await getAllCategories();
    if (response?.data) {
      setCategories(response.data.categories);
    }
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  return (
    <Box maxW="lg" mx="auto" mt={5}>
      <Progress colorScheme="teal" background="#fbf7f7" hasStripe value={progress} mb="5%" mx="5%" isAnimated />

      <form onSubmit={handleSubmit}>
        {step === 1 && (
          <Box>
            <FormControl mb={4}>
              <FormLabel>Categoría</FormLabel>
              {categories &&
                <Select
                  name="category_id"
                  value={formData.category_id}
                  onChange={handleChange}
                >
                  {categories.map((cat, index) => (
                    <option value={cat.id} key={index}>
                      {cat.name}
                    </option>
                  ))}
                </Select>
              }
            </FormControl>

            <FormControl mb={4}>
              <FormLabel>Nombre</FormLabel>
              <Input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="Nombre del Producto"
              />
            </FormControl>

            <FormControl mb={4}>
              <FormLabel>Descripción</FormLabel>
              <Textarea
                name="description"
                value={formData.description}
                onChange={handleChange}
                placeholder="Descripción del Producto"
              />
            </FormControl>

            <FormControl mb={4}>
              <FormLabel>Precio</FormLabel>
              <Input
                type="text"
                name="price"
                value={formData.price}
                onChange={handleChange}
                placeholder="Precio del Producto"
              />
            </FormControl>

            <Button colorScheme="teal" onClick={handleNextStep}>
              Siguiente
            </Button>
          </Box>
        )}

        {step === 2 && (
          <Box>
            <FormControl mb={4} p={4}>
              <FormLabel>Imagen del Producto</FormLabel>
              <Box padding={4} border={'1px dashed gray'} borderColor={'teal'} borderRadius={8}>
                <Input
                  border="none"
                  type="file"
                  name="image"
                  accept="image/*"
                  onChange={handleImageChange}
                />
              </Box>
              {formData.imagePreviewUrl && (
                <Box mt={4}>
                  <Image
                    src={formData.imagePreviewUrl}
                    alt="Vista previa de la imagen"
                  />
                </Box>
              )}
            </FormControl>

            <Button colorScheme="teal" onClick={handlePrevStep} mr={4}>
              Anterior
            </Button>
            <Button colorScheme="teal" onClick={handleNextStep}>
              Siguiente
            </Button>
          </Box>
        )}

        {step === 3 && (
          <Box>
            <h2>Resumen</h2>
            <ProductCard
              Product={{
                ...formData,
                img: formData.imagePreviewUrl, // Aquí asegúrate de pasar la URL de la imagen
                price_old: formData.price - (formData.price * 0.2),
              }}
            />
            <Button colorScheme="teal" onClick={handlePrevStep} mr={4}>
              Anterior
            </Button>
            <Button
              colorScheme="teal"
              variant="outline"
              type="submit"
              isDisabled={loading}
            >
              {loading ? <Spinner size="sm" /> : 'Guardar Producto'}
            </Button>
          </Box>
        )}
      </form>
    </Box>
  );
};

export default ProductCreator;


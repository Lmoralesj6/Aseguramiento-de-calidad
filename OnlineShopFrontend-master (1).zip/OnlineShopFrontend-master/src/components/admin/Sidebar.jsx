
import React from 'react';
import {
  Box,
  IconButton,
  VStack,
  Text,
  useColorModeValue,
  Button,
  Accordion,
  Stack,
  AccordionItem,
  AccordionButton,
  AccordionPanel,
  AccordionIcon,
} from '@chakra-ui/react';
import { FaBoxOpen, FaPlus, FaMinus, FaEdit, FaListAlt, FaFileInvoiceDollar } from "react-icons/fa";
import { BiSolidReport } from "react-icons/bi";
import { FaHome, FaUserAlt, FaCog, FaSignOutAlt, FaTimes, FaShoppingCart, FaComments } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';

const Sidebar = ({ toggleSidebar }) => {
  const bg = useColorModeValue('gray.100', 'gray.900');
  const color = useColorModeValue('gray.900', 'gray.100');
  const history = useNavigate();


  const redirect = (link) => {
    toggleSidebar();
    history(link);
  }

  return (
    <Box
      position="fixed"
      left={0}
      top={0}
      w="250px"
      h="100vh"
      bg={bg}
      boxShadow="lg"
      p={5}
    >
      <VStack spacing={4} align="stretch" justifyContent="flex-start">
        {/* Botón para cerrar el sidebar */}
        <IconButton
          icon={<FaTimes />}
          aria-label="Cerrar Sidebar"
          fontSize="12px"
          alignSelf="flex-end"
          color='gray.300'
          bg='gray.100'
          _hover={{ color: 'gray.400', bg: 'gray.200' }}
          onClick={toggleSidebar}
        />

        <Text fontSize="2xl" fontWeight="bold" color={'pink.600'} mb={8}>
          DivasOnline
        </Text>

        <Accordion allowToggle>
          <AccordionItem border='none' mt={2} color='pink.600'>
            <AccordionButton>
              <Box flex="1" textAlign="left" display="flex" alignItems="center" >
                <FaHome style={{ marginRight: '8px' }} />
                Inicio
              </Box>
              <AccordionIcon />
            </AccordionButton>
            <AccordionPanel pb={4}>
              <Button
                variant="ghost"
                colorScheme="pink"
                justifyContent="flex-start"
                w="100%"
                onClick={() => redirect('/admin/dashboard')}
              >
                Inicio
              </Button>
            </AccordionPanel>
          </AccordionItem>


          <AccordionItem border='none' mt={2} color='pink.600'>
            <AccordionButton>
              <Box flex="1" textAlign="left" display="flex" alignItems="center">
                <FaBoxOpen style={{ marginRight: '8px' }} />
                Productos
              </Box>
              <AccordionIcon />
            </AccordionButton>
            <AccordionPanel pb={4}>
              <Button
                variant="ghost"
                colorScheme="pink"
                justifyContent="flex-start"
                w="100%"
                fontWeight={'normal'}
              >
                <Box flex="1" textAlign="left" display="flex" alignItems="center" fontSize={14} onClick={() => redirect('/admin/producto/nuevo')}>
                  <FaPlus style={{ marginRight: '8px' }} fontSize={10} />
                  Nuevo
                </Box>
              </Button>
              <Button
                variant="ghost"
                colorScheme="pink"
                justifyContent="flex-start"
                w="100%"
                fontWeight={'normal'}
              >
                <Box flex="1" textAlign="left" display="flex" alignItems="center" fontSize={14} onClick={() => redirect('/admin/producto/visualizar')}>
                  <FaListAlt style={{ marginRight: '8px' }} fontSize={10} />
                  List
                </Box>
              </Button>
            </AccordionPanel>
          </AccordionItem>


          <AccordionItem border='none' mt={2} color='pink.600'>
            <AccordionButton>
              <Box flex="1" textAlign="left" display="flex" alignItems="center">
                <FaBoxOpen style={{ marginRight: '8px' }} />
                Categorías
              </Box>
              <AccordionIcon />
            </AccordionButton>
            <AccordionPanel pb={4}>
              <Button
                variant="ghost"
                colorScheme="pink"
                justifyContent="flex-start"
                w="100%"
                fontWeight={'normal'}
              >
                <Box flex="1" textAlign="left" display="flex" alignItems="center" fontSize={14} onClick={() => redirect('/admin/categoria/nuevo')}>
                  <FaPlus style={{ marginRight: '8px' }} fontSize={10} />
                  Nuevo
                </Box>
              </Button>
              <Button
                variant="ghost"
                colorScheme="pink"
                justifyContent="flex-start"
                w="100%"
                fontWeight={'normal'}
              >
                <Box flex="1" textAlign="left" display="flex" alignItems="center" fontSize={14} onClick={() => redirect('/admin/categoria/visualizar')}>
                  <FaListAlt style={{ marginRight: '8px' }} fontSize={10} />
                  List
                </Box>
              </Button>

            </AccordionPanel>
          </AccordionItem>


          <AccordionItem border='none' mt={2} color='pink.600'>
            <AccordionButton>
              <Box flex="1" textAlign="left" display="flex" alignItems="center">
                <FaUserAlt style={{ marginRight: '8px' }} />
                Usuarios
              </Box>
              <AccordionIcon />
            </AccordionButton>
            <AccordionPanel pb={4}>
              <Button
                variant="ghost"
                colorScheme="pink"
                justifyContent="flex-start"
                w="100%"
                fontWeight={'normal'}
              >
                <Box flex="1" textAlign="left" display="flex" alignItems="center" fontSize={14} onClick={() => redirect('/admin/usuario/visualizar')}>
                  <FaListAlt style={{ marginRight: '8px' }} fontSize={10} />
                  List
                </Box>
              </Button>
            </AccordionPanel>
          </AccordionItem>


          <AccordionItem border='none' mt={2} color='pink.600'>
            <AccordionButton>
              <Box flex="1" textAlign="left" display="flex" alignItems="center">
                <FaShoppingCart style={{ marginRight: '8px' }} />
                Pedidos
              </Box>
              <AccordionIcon />
            </AccordionButton>
            <AccordionPanel pb={4}>
              <Button
                variant="ghost"
                colorScheme="pink"
                justifyContent="flex-start"
                w="100%"
                fontWeight={'normal'}
              >
                <Box flex="1" textAlign="left" display="flex" alignItems="center" fontSize={14} onClick={() => redirect('/admin/pedidos/visualizar')}>
                  <FaListAlt style={{ marginRight: '8px' }} fontSize={10} />
                  List
                </Box>
              </Button>
            </AccordionPanel>
          </AccordionItem>


          <AccordionItem border='none' mt={2} color='pink.600'>
            <AccordionButton>
              <Box flex="1" textAlign="left" display="flex" alignItems="center">
                <FaComments style={{ marginRight: '8px' }} />
                Contactos
              </Box>
              <AccordionIcon />
            </AccordionButton>
            <AccordionPanel pb={4}>
              <Button
                variant="ghost"
                colorScheme="pink"
                justifyContent="flex-start"
                w="100%"
                fontWeight={'normal'}
              >
                <Box flex="1" textAlign="left" display="flex" alignItems="center" fontSize={14} onClick={() => redirect('/admin/contactos/visualizar')}>
                  <FaListAlt style={{ marginRight: '8px' }} fontSize={10} />
                  List
                </Box>
              </Button>
            </AccordionPanel>
          </AccordionItem>


          <AccordionItem border='none' mt={2} color='pink.600'>
            <AccordionButton>
              <Box flex="1" textAlign="left" display="flex" alignItems="center">
                <FaFileInvoiceDollar style={{ marginRight: '8px' }} />
                Cotizaciones
              </Box>
              <AccordionIcon />
            </AccordionButton>
            <AccordionPanel pb={4}>
              <Button
                variant="ghost"
                colorScheme="pink"
                justifyContent="flex-start"
                w="100%"
                fontWeight={'normal'}
              >
                <Box flex="1" textAlign="left" display="flex" alignItems="center" fontSize={14} onClick={() => redirect('/admin/cotizaciones/visualizar')}>
                  <FaListAlt style={{ marginRight: '8px' }} fontSize={10} />
                  List
                </Box>
              </Button>
            </AccordionPanel>
          </AccordionItem>


          <AccordionItem border='none' mt={2} color='pink.600'>
            <AccordionButton>
              <Box flex="1" textAlign="left" display="flex" alignItems="center">
                <FaCog style={{ marginRight: '8px' }} />
                Configuración
              </Box>
              <AccordionIcon />
            </AccordionButton>
            <AccordionPanel pb={4}>
              <Button
                variant="ghost"
                colorScheme="pink"
                justifyContent="flex-start"
                w="100%"
              >
                Preferencias
              </Button>
              <Button
                variant="ghost"
                colorScheme="pink"
                justifyContent="flex-start"
                w="100%"
              >
                Seguridad
              </Button>
            </AccordionPanel>
          </AccordionItem>
          <AccordionItem border='none' mt={2} color='pink.600'>
            <AccordionButton>
              <Box flex="1" textAlign="left" display="flex" alignItems="center" >
                <BiSolidReport style={{ marginRight: '8px' }} />
                Reportes
              </Box>
              <AccordionIcon />
            </AccordionButton>
            <AccordionPanel pb={4}>
              <Button
                onClick={() => redirect('/admin/reports/visualizar')}
                variant="ghost"
                colorScheme="pink"
                justifyContent="flex-start"
                w="100%"
              >
                Todos los reportes
              </Button>
            </AccordionPanel>
          </AccordionItem>

        </Accordion>

        <Button
          leftIcon={<FaSignOutAlt />}
          aria-label="Salir"
          fontSize="14px"
          _hover={{ background: 'pink.100' }}
          w="100%"
          variant="ghost"
          colorScheme="pink"
          justifyContent="flex-start"
        >
          Salir
        </Button>
      </VStack>
    </Box>
  );
};

export default Sidebar;


import React, { useState } from 'react';
import {
  Box,
  Button,
  FormControl,
  FormLabel,
  Input,
  Textarea,
  useToast,
  Spinner,
  Text,
  Flex,
} from '@chakra-ui/react';
import { createCategory } from '../../services/categoryService';
import { useNavigate } from 'react-router-dom';

const CategoryCreator = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
  });
  const [errors, setErrors] = useState({});
  const toast = useToast();

  const handleChange = (e) => {
    setFormData((prevData) => ({
      ...prevData,
      [e.target.name]: e.target.value,
    }));
  };

  const validateFields = () => {
    let validationErrors = {};
    if (!formData.name) {
      validationErrors.name = 'El campo Nombre es requerido.';
    }
    if (!formData.description) {
      validationErrors.description = 'El campo Descripción es requerido.';
    }
    return validationErrors;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (loading) return;

    const validationErrors = validateFields();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      toast({
        title: 'Error',
        description: 'Por favor, complete todos los campos obligatorios.',
        status: 'error',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right',
      });
      return;
    }

    setLoading(true);
    setErrors({});

    try {
      const newCategory = {
        name: formData.name,
        description: formData.description,
      };

      console.log(newCategory);
      const response = await createCategory(newCategory);
      if (response.status === 200) {
        toast({
          title: 'Categoría creada correctamente',
          description: 'Todos los campos están llenos.',
          status: 'success',
          duration: 3000,
          isClosable: true,
          position: 'bottom-right',
        });
        navigate('/admin/dashboard');
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Hubo un problema al crear la categoría.',
        status: 'error',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box maxW="lg" mx="auto" mt={5}>
      <form onSubmit={handleSubmit}>
        <FormControl mb={4} isInvalid={errors.name}>
          <FormLabel>Nombre</FormLabel>
          <Input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="Nombre de la Categoría"
          />
          {errors.name && <Text color="red.500">{errors.name}</Text>} {/* Mensaje de error */}
        </FormControl>

        <FormControl mb={4} isInvalid={errors.description}>
          <FormLabel>Descripción</FormLabel>
          <Textarea
            name="description"
            value={formData.description}
            onChange={handleChange}
            placeholder="Descripción de la Categoría"
          />
          {errors.description && <Text color="red.500">{errors.description}</Text>} {/* Mensaje de error */}
        </FormControl>

        <Flex justifyContent="center">
          <Button
            colorScheme="teal"
            variant="outline"
            type="submit"
            isDisabled={loading}
          >
            {loading ? <Spinner size="sm" /> : 'Guardar Categoría'}
          </Button>
        </Flex>
      </form>
    </Box>
  );
};

export default CategoryCreator;

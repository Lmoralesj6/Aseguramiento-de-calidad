
import React, { useState, useEffect } from 'react';
import { Box, Image, Text, Flex, IconButton, ButtonGroup, Button } from '@chakra-ui/react';
import { CloseIcon, AddIcon, MinusIcon } from '@chakra-ui/icons';
import { useCart } from '../../hooks/CartContext';
import { useToast } from '@chakra-ui/react';

const CartItem = ({ product }) => {
  const [quantity, setQuantity] = useState(product.cantidad || 1);
  const { dispatch } = useCart();
  const toast = useToast();
  const defaultImg = 'https://images.unsplash.com/photo-1494228766058-1430438d10fc?q=80&w=1473&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D';

  // Actualizar el carrito cuando la cantidad cambia
  useEffect(() => {
    dispatch({ type: 'UPDATE', id: product.id, cantidad: quantity });
  }, [quantity, dispatch, product.id]);

  const handleRemove = () => {
    dispatch({ type: 'REMOVE', id: product.id });
    toast({
      title: 'Producto Eliminado',
      description: 'Producto eliminado del carrito',
      status: 'error',
      duration: 3000,
      isClosable: true,
      position: 'bottom-right'
    });
  };

  const incrementQuantity = () => {
    setQuantity(prevQuantity => prevQuantity + 1);
  };

  const decrementQuantity = () => {
    if (quantity > 1) {
      setQuantity(prevQuantity => prevQuantity - 1);
    }
  };

  return (
    <Box
      borderWidth="1px"
      borderRadius="lg"
      overflow="hidden"
      boxShadow="sm"
      bg="white"
      w="100%"
      p={2}
      mb={2}
      _hover={{ boxShadow: 'md' }}
    >
      <Flex alignItems="center">
        <Image
          src={product.img ?? defaultImg}
          alt={product.name}
          boxSize="60px"
          objectFit="cover"
          borderRadius="md"
          mr={3}
          mb={0}
        />
        <Box flex="1" mr={2}>
          <Text fontWeight="bold" fontSize="sm" isTruncated mb={0}>
            {product.name}
          </Text>
          <Text fontSize="xs" color="gray.500" isTruncated mb={0}>
            {product.description}
          </Text>
          <Text fontWeight="bold" fontSize="md" mt={1} mb={0}>
            Q{product.price * product.cantidad}
          </Text>
        </Box>
        <ButtonGroup size="sm" isAttached variant="outline" mr={2}>
          <IconButton icon={<MinusIcon />} onClick={decrementQuantity} />
          <Button>{quantity}</Button>
          <IconButton icon={<AddIcon />} onClick={incrementQuantity} />
        </ButtonGroup>
        <IconButton
          aria-label="Remove item"
          icon={<CloseIcon />}
          size="sm"
          onClick={handleRemove}
          variant="ghost"
          colorScheme="red"
        />
      </Flex>
    </Box>
  );
};

export default CartItem;



import {
  Box,
  Center,
  useColorModeValue,
  chakra,
  Heading,
  Icon,
  Text,
  Stack,
  Image,
  Tooltip
} from '@chakra-ui/react'
import Rating from './RatingProduct';
import { FiShoppingCart } from 'react-icons/fi'
import { useCart } from '../../hooks/CartContext';
import { useToast } from '@chakra-ui/react';
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { checker } from '../../utils/image';
import { BsFillBookmarkFill } from "react-icons/bs";
import { useFavorites } from '../../hooks/FavoritesProvider';
import { isAdmin } from '../../utils/authChecker';


const ProductCard = ({ Product }) => {
  const toast = useToast();
  const { dispatch } = useCart();
  const { favorites, addToFavorites, removeFromFavorites } = useFavorites();
  const [isHovered, setIsHovered] = useState(false);
  const history = useNavigate();
  const defaultImg = 'https://images.unsplash.com/photo-1494228766058-1430438d10fc?q=80&w=1473&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D';
  const [imgSrc, setImgSrc] = useState(defaultImg);
  const [favorite, setFavorite] = useState(false);
  const user = JSON.parse(localStorage.getItem('user'));
  const hideFavorite = user ? isAdmin(user.roles) : false;

  useEffect(() => {
    const verificarImagen = async () => {
      const existe = await checker(Product.img);
      setImgSrc(existe ? Product.img : defaultImg);
    };

    verificarImagen();
  }, [Product.img]);

  useEffect(() => {
    const isFavorite = favorites.length < 1 ? false : favorites.some(fav => fav.id === Product.id);
    setFavorite(isFavorite);
  }, [favorites, Product.id]);

  const addToCart = () => {
    toast({
      title: 'Nuevo Producto',
      description: 'Producto agregado al carrito',
      status: 'success',
      duration: 3000,
      isClosable: true,
      position: 'bottom-right'
    });
    dispatch({ type: 'ADD', item: Product });
  }

  const toggleFavorite = async () => {
    if (favorite) {
      await removeFromFavorites(Product);
      toast({
        title: 'Favorito removido',
        description: 'Producto eliminado de tus favoritos',
        status: 'info',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right'
      });
    } else {
      await addToFavorites(Product);
      toast({
        title: 'Añadido a favoritos',
        description: 'Producto agregado a tus favoritos',
        status: 'success',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right'
      });
    }
    setFavorite(!favorite);
  }

  return (
    <Center py={12}>
      <Box
        role={'group'}
        p={6}
        maxW={'330px'}
        w={'full'}
        bg={useColorModeValue('white', 'gray.800')}
        boxShadow={'2xl'}
        rounded={'lg'}
        pos={'relative'}
        zIndex={1}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <Box
          onClick={() => history(`/Producto/${Product.id}`)}
          rounded={'lg'}
          mt={-12}
          pos={'relative'}
          height={'230px'}
          _after={{
            transition: 'all .3s ease',
            content: '""',
            w: 'full',
            h: 'full',
            pos: 'absolute',
            top: 5,
            left: 0,
            backgroundImage: `url(${Product.img})`,
            filter: 'blur(15px)',
            zIndex: -1,
          }}
          _groupHover={{
            _after: {
              filter: 'blur(20px)',
            },
          }}
        >
          <Image
            rounded={'lg'}
            height={230}
            width={282}
            objectFit={'cover'}
            src={imgSrc}
            alt="#"
            style={{
              filter: isHovered ? 'blur(6px) brightness(70%)' : 'none',
              cursor: 'pointer',
              transition: '.35s',
            }}
          />
          {isHovered && (
            <Box
              className="visualize-text"
              position="absolute"
              top="50%"
              left="50%"
              transform="translate(-50%, -50%)"
              color="white"
              fontWeight="bold"
              _hover={{ cursor: 'pointer' }}
              fontSize="2rem"
              zIndex="10"
            >
              Visualizar
            </Box>
          )}
        </Box>
        <Stack pt={10} align={'center'}>
          <Text color={'gray.500'} fontSize={'sm'} textTransform={'uppercase'}>
            {Product.name}
          </Text>
          <Heading fontSize={'2xl'} fontFamily={'body'} fontWeight={500}>
            {Product.description}
          </Heading>
          <Stack direction={'row'} align={'center'}>
            <Text fontWeight={800} fontSize={'xl'}>
              Q.{Product.price}
            </Text>
            <Text textDecoration={'line-through'} color={'gray.600'}>
              Q.{Product.price_old}
            </Text>
          </Stack>
          <Stack direction={'row'} align='center'>
            {hideFavorite &&
              <Icon
                title={favorite ? 'Quitar de favoritos' : 'Agregar a favoritos'}
                as={BsFillBookmarkFill}
                onClick={toggleFavorite}
                color={!favorite ? 'gray.300' : 'yellow.500'}
                _hover={{ color: 'yellow.400', cursor: 'pointer' }}
              />
            }
            <Rating rating={Product.rating} numReviews={Product.reviews} />
            <Tooltip
              label="Add to cart"
              bg="white"
              placement={'top'}
              color={'gray.800'}
              fontSize={'1.2em'}>
              <chakra.a display={'flex'} onClick={addToCart} _hover={{ cursor: 'pointer' }}>
                <Icon as={FiShoppingCart} h={7} w={7} alignSelf={'center'} />
              </chakra.a>
            </Tooltip>
          </Stack>
        </Stack>
      </Box>
    </Center>
  )
}

export default ProductCard;


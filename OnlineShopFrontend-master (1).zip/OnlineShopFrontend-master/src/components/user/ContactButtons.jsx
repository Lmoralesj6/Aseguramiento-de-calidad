import {
  Box,
  IconButton,
  Stack,
  Tooltip,
  useClipboard,
  useColorModeValue,
} from "@chakra-ui/react";
import {  BsTiktok, BsPerson, BsInstagram, BsWhatsapp } from "react-icons/bs";
import { MdEmail, MdOutlineEmail } from "react-icons/md";

const ContactButtons = () => {
  const { hasCopied, onCopy } = useClipboard("divasonlinegt502@gmail.com");
  return (
    <Stack
      align="center"
      justify="space-around"
      direction={{ base: "row", md: "column" }}
    >
      <Tooltip
        label={hasCopied ? "Correo electronico copiado!" : "Copiar correo electronico"}
        closeOnClick={false}
        hasArrow
      >
        <IconButton
          aria-label="email"
          variant="ghost"
          size="lg"
          fontSize="3xl"
          icon={<MdEmail />}
          _hover={{
            bg: "blue.500",
            color: useColorModeValue("white", "gray.700"),
          }}
          onClick={onCopy}
          isRound
        />
      </Tooltip>

      <Box as="a" href="https://www.instagram.com/divasonlinegt/" target="_blank">
      <Tooltip
        label={"Instagram"}
      >
        <IconButton
          aria-label="Instagram"
          variant="ghost"
          size="lg"
          icon={<BsInstagram  size="28px" />}
          _hover={{
            bg: "blue.500",
            color: useColorModeValue("white", "gray.700"),
          }}
          isRound
        />
        </Tooltip>
      </Box>

      <Box as="a" href="https://www.tiktok.com/@divasonlinegt?_t=8pRcsorZJwr&_r=1" target="_blank">
        <Tooltip label={"Tiktok"}>
          <IconButton
            aria-label="Tiktok"
            variant="ghost"
            size="lg"
            icon={<BsTiktok size="28px" />}
            _hover={{
              bg: "blue.500",
              color: useColorModeValue("white", "gray.700"),
            }}
            isRound
          />
        </Tooltip>
      </Box>

      <Box as="a" href="https://wa.me/50255702714?text=Hola! Me gustaría obtener más información sobre sus productos" target="_blank">
        <Tooltip label={"Whatsapp"}>
          <IconButton
            aria-label="Whatsapp"
            variant="ghost"
            size="lg"
            icon={<BsWhatsapp  size="28px" />}
            _hover={{
              bg: "blue.500",
              color: useColorModeValue("white", "gray.700"),
            }}
            isRound
          />
        </Tooltip>
      </Box>
    </Stack>
  );
};

export default ContactButtons;


import { Box } from "@chakra-ui/react";
import React, { useRef, useEffect, useState } from "react";
import ProductComments from "./ProductComments";

const ProductCommentsContainer = ({ reviews }) => {
  const [currentMsg, setCurrentMsg] = useState(0);
  const containerRef = useRef(null);

  useEffect(() => {
    const div = containerRef.current;
    const handleScroll = (event) => {
      event.preventDefault(); // Evita el scroll nativo
      if (event.deltaY > 0) {
        setCurrentMsg((prev) => Math.min(prev + 1, reviews.length - 1));
      } else {
        setCurrentMsg((prev) => Math.max(prev - 1, 0));
      }
    };

    div.addEventListener('wheel', handleScroll, { passive: false });

    return () => div.removeEventListener('wheel', handleScroll);
  }, []);  // Dependencia actualizada

  return (
    <Box
      ref={containerRef}
      flex="1"
      overflowY="hidden"  // Posiblemente quieras controlar completamente el scroll
      p={4}
      mb={4}
      display="flex"
      height="10vh"
      justifyContent="center"
      alignItems="center"
    >
      <ProductComments currentIndex={currentMsg} comments={reviews} />
    </Box>
  );
};

export default ProductCommentsContainer;



import React from 'react';
import { getAll } from '../../services/productService';
import ProductSlider from './ProductSlider';

const ProductCardContainer = ({ children }) => {
  const [prds, setPrds] = React.useState([]);


  const fetch = async () => {
    const response = await getAll();
    if (response.data) {
      const { products } = response.data;
      setPrds(products);
    }
  }

  React.useEffect(() => {
    fetch();
  }, []);

  if (children) {
    return (
      <div>
        {children}
      </div>
    )
  }


  return (
    <div>
      {prds &&
        <ProductSlider prds={prds} />
      }
    </div>
  );
};

export default ProductCardContainer;


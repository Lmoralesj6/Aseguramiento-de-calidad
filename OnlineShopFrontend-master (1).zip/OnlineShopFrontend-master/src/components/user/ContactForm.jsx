import {
  Box,
  Button,
  FormControl,
  FormLabel,
  Input,
  InputGroup,
  InputLeftElement,
  useToast,
  Textarea,
  useColorModeValue,
  VStack,
} from "@chakra-ui/react";
import { BsGithub, BsLinkedin, BsPerson, BsTwitter } from "react-icons/bs";
import { MdEmail, MdOutlineEmail } from "react-icons/md";
import { useState, useEffect } from "react";
import { sendContactMessage } from "../../services/contactService";

const ContactForm = () => {
  const empty_form = { name: "", email: "", message: "" };
  const [form, setForm] = useState(empty_form);
  const [showButton, setShowButton] = useState(false);
  const toast = useToast();

  useEffect(() => {
    if (
      form.email.length !== 0 &&
      form.message.length !== 0 &&
      form.name.length !== 0
    ) {
      setShowButton(true);
    } else {
      setShowButton(false);
    }
  }, [form]);

  const handleChange = (event) => {
    const name = event.target.name;
    const value = event.target.value;
    setForm((values) => ({ ...values, [name]: value }));
  };

  const enviarForm = async () => {
    if (form.email === "" || form.message === "") {
      toast({
        title: 'Error al enviar mensaje',
        description: 'Debe completar los campos del formulario',
        status: 'error',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right'
      });
      return;
    }
    const response = await sendContactMessage(form.name, form.email, form.message);
    console.log(response);
    if (response.status === 200) {
      toast({
        title: 'Mensaje enviado',
        description: 'Mensaje enviado correctamente',
        status: 'success',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right'
      });
    }
    setForm(empty_form);
  };

  return (
    <Box
      bg={useColorModeValue("white", "gray.700")}
      borderRadius="lg"
      p={10}
      color={useColorModeValue("gray.700", "whiteAlpha.900")}
      shadow="base"
      width="30vw"
    >
      <VStack spacing={2}>
        <FormControl isRequired>
          <FormLabel>Nombre</FormLabel>

          <InputGroup>
            <InputLeftElement>
              <BsPerson />
            </InputLeftElement>
            <Input
              type="text"
              name="name"
              value={form.name}
              onChange={handleChange}
              placeholder="Your Name"
            />
          </InputGroup>
        </FormControl>

        <FormControl isRequired>
          <FormLabel>Correo</FormLabel>

          <InputGroup>
            <InputLeftElement>
              <MdOutlineEmail />
            </InputLeftElement>
            <Input
              type="email"
              name="email"
              placeholder="Your Email"
              value={form.email}
              onChange={handleChange}
            />
          </InputGroup>
        </FormControl>

        <FormControl isRequired>
          <FormLabel>Mensaje</FormLabel>

          <Textarea
            name="message"
            placeholder="Your Message"
            rows={6}
            resize="none"
            value={form.message}
            onChange={handleChange}
          />
        </FormControl>

        {showButton ? (
          <Button
            colorScheme="blue"
            bg="blue.400"
            color="white"
            _hover={{
              bg: "blue.500",
            }}
            width="full"
            onClick={enviarForm}
          >
            Enviar mensaje
          </Button>
        ) : (
          ""
        )}
      </VStack>
    </Box>
  );
};

export default ContactForm;

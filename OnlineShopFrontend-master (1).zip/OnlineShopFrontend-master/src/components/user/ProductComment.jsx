import { Box, Flex, Avatar, Stack, Text } from "@chakra-ui/react";
import React from "react";
import Rating from "./RatingProduct";
const ProductComment = ({ comment }) => {


  React.useEffect(() => {
    console.log(comment);
  }, []);

  return (
    <Box width="100%" padding="2" bg="white" boxShadow="lg" borderRadius="md" >
      <Flex alignItems="center">
        <Avatar
          size="sm"
          name={comment.username}
          src={comment.profile}
          marginRight="4"
        />
        <Stack spacing={0}>
          <Text color="gray.500" fontSize={'0.6rem'}>{comment.username}</Text>
        </Stack>
      </Flex>
      <Text mt={-16.4} ml={12} fontSize="0.6rem">
        {comment.comment}
      </Text>
      <Rating rating={comment.rating} numReviews={1} />
    </Box>
  )
}

export default ProductComment;


import React, { useEffect, useState } from 'react';
import { useCart } from "../../hooks/CartContext";
import { Flex, Container, Heading, Box, Text, Divider, VStack, Button } from "@chakra-ui/react";
import CartItem from "./CartItem";
import { BsFillTrashFill } from "react-icons/bs";
import { useToast } from '@chakra-ui/react';
import { getUserInfo } from '../../services/productService';
import { createOrder } from '../../services/cartService';
import Loader from "../common/Loader"; // Adjust the import path accordingly
import LoadingButton from '../common/LoadingButton';
import ShippingAddress from './ShippingAddress';

const Cart = () => {
  const { cart, dispatch } = useCart();
  const toast = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [user, setUser] = useState(null);
  const [address, setAddress] = useState(null);

  const handleAddressChange = (address) => {
    console.log(address);
    setAddress(address);
  };

  const cleanCart = (showMessage = true) => {
    dispatch({ type: 'CLEAN' });
    if (showMessage) {
      toast({
        title: 'Vaciando Carrito',
        description: 'Se ha cancelado el carrito',
        status: 'warning',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right'
      });
    }
  }


  const validateAddress = (address) => {

    if (!address) {
      toast({
        title: 'Error en el pedido',
        description: 'Por favor, completa todos los campos de dirección.',
        status: 'error',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right',
      });
      return;
    }

    const { department, municipality, exact_address, references } = address;

    if (!department || !municipality || !exact_address || !references) {
      toast({
        title: 'Error en el pedido',
        description: 'Por favor, completa todos los campos de dirección.',
        status: 'error',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right',
      });
      return false;
    }

    return true;
  };

  const saveCart = async () => {
    setIsLoading(true);
    const token = JSON.parse(localStorage.getItem('token'));
    if (!token) {
      toast({
        title: 'Usuario sin sesión',
        description: 'Debe iniciar sesión para poder confirmar el pedido',
        status: 'warning',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right'
      });
      setIsLoading(false);
      return;
    }
    try {
      if (user) {
        if (!validateAddress(address)) return;
        const response = await createOrder(cart, user.id, address);
        if (response.status == 200) {
          cleanCart(false);
          toast({
            title: 'Pedido Realizado',
            description: 'Pedido guardado correctamente',
            status: 'success',
            duration: 3000,
            isClosable: true,
            position: 'bottom-right'
          });
          return;
        }
        console.log(response);
      }
    } catch (error) {
      console.error(error);
      toast({
        title: 'Error al guardar el pedido',
        description: 'Hubo un problema al intentar guardar su pedido, intente nuevamente.',
        status: 'error',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right'
      });
    } finally {
      setIsLoading(false);
    }
  }


  useEffect(() => {
    const getUser = async () => {
      const response = await getUserInfo();
      console.log(response.data);
      if (response.status === 200) {
        setUser(response.data);
      }
    }
    getUser();
  }, []);

  return (

    <Flex
      className='cart'
      p={4}
      bg="gray.50"
      justify={cart.length !== 0 ? "center" : ''}
      align={cart.length !== 0 ? 'center' : ''}
    >
      <Loader isLoading={isLoading} />
      <Container
        maxW="4xl"
        bg="white"
        boxShadow="xl"
        rounded="lg"
        p={6}
      >
        <Heading
          as="h2"
          fontSize={{ base: "xl", sm: "2xl" }}
          textAlign="center"
          color="pink.600"
          mb={5}
        >
          Carrito de compras
        </Heading>

        <Box>
          <Flex justify="space-between" mb={6}>
            <Text>Envío estándar</Text>
            <Text color="green.600">Q15.00</Text>
          </Flex>
          <Divider />

          <Box flex="1" overflowY="auto" my={4}>
            <VStack spacing="12px">
              {cart && cart.length !== 0 ? (
                cart.map((item, index) => (
                  <CartItem key={index} product={item} />
                ))
              ) : (
                <Text textAlign="center" color="gray.500">
                  Tu carrito está vacío...
                </Text>
              )}
            </VStack>
          </Box>
          <Divider />

          {cart.length !== 0 && (
            <div>
              <Flex justify="space-between" my={4}>
                <Text fontWeight="bold" color={'blackAlpha.500'}>Subtotal</Text>
                <Text fontWeight="bold" color="blackAlpha.600">Q{cart.reduce((total, item) => total + item.price * item.cantidad, 0)}</Text>
              </Flex>
              <Divider />

              <Flex justify="space-between" my={4}>
                <Text fontWeight="bold" color='pink.600'>TOTAL</Text>
                <Text fontWeight="bold" color="pink.600">Q{cart.length !== 0 ? (parseInt(cart.reduce((total, item) => total + item.price * item.cantidad, 0)) + 15) : '0.00'}</Text>
              </Flex>

              <Divider />
              <ShippingAddress onAddressChange={handleAddressChange} />

              <Flex direction="row" width="100%" gap={2}>
                <LoadingButton
                  mt={4}
                  isLoading={isLoading}
                  fontSize="sm"
                  fontWeight={600}
                  color="white"
                  bg="pink.400"
                  href="#"
                  _hover={{
                    bg: "pink.500",
                  }}
                  flex="0 0 90%"
                  onClick={saveCart}
                >
                  Confirmar
                </LoadingButton>
                <Button
                  mt={4}
                  title='Limpiar Carrito'
                  onClick={cleanCart}
                  fontSize="sm"
                  fontWeight={600}
                  color="white"
                  bg="red.500"
                  href="#"
                  _hover={{
                    bg: "red.700",
                  }}
                  flex="0 0 10%"
                >
                  <BsFillTrashFill />
                </Button>
              </Flex>
            </div>
          )}
        </Box>
      </Container>
    </Flex>
  );
};

export default Cart;


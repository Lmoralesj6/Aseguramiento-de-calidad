import React from 'react';
import { Box, HStack, Button, IconButton } from '@chakra-ui/react';
import { ArrowBackIcon, ArrowForwardIcon } from '@chakra-ui/icons';
import ProductCard from './ProductCard';
import { getUrl } from '../../utils/productRender';

const ProductSlider = ({ prds }) => {
  const [scrollPosition, setScrollPosition] = React.useState(0);
  const sliderRef = React.useRef(null);
  const handleScrollLeft = () => {
    if (sliderRef.current) {
      sliderRef.current.scrollLeft -= 400;
      setScrollPosition(sliderRef.current.scrollLeft - 400);
    }
  };

  const handleScrollRight = () => {
    if (sliderRef.current) {
      sliderRef.current.scrollLeft += 400;
      setScrollPosition(sliderRef.current.scrollLeft + 400);
    }
  };


  const getObjectProduct = (item) => {
    var img_url = getUrl(item.images);
    return {
      id: item.id,
      name: item.name,
      description: item.description,
      rating: 5,
      price: item.price,
      price_old: parseFloat(item.price) + (parseFloat(item.price) * 0.15),
      reviews: 10,
      img: img_url
    }
  }
  return (
    <div style={{ position: 'relative' }} className='slide-container'>
      <Box maxW="1200px" overflowX={'hidden'} mx="auto" py={14} position="relative" className='slider-container' paddingTop={0}>
        <IconButton
          icon={<ArrowBackIcon />}
          className='btn-izq'
          position="absolute"
          left="0%"
          top="50%"
          transform="translateY(-50%)"
          onClick={handleScrollLeft}
          zIndex={2}
          aria-label="Scroll left"
        />
        <Box
          ref={sliderRef}
          display="flex"
          overflowX="hidden"
          gap={12}
          padding={2}
          scrollBehavior="smooth"
          maxW="1200px"
          mx="auto"
          margin={10}
          spacing={10}
          marginInline={'4rem'}
          paddingBottom="1rem"
        >
          {
            prds.map((prd, index) => (
              <Box flex="none" key={index}>
                <ProductCard Product={getObjectProduct(prd)} />
              </Box>
            ))
          }
        </Box>
        <IconButton
          icon={<ArrowForwardIcon />}
          position="absolute"
          right="0%"
          top="50%"
          transform="translateY(-50%)"
          onClick={handleScrollRight}
          zIndex={2}
          aria-label="Scroll right"
        />
      </Box>

    </div>
  )
}

export default ProductSlider;

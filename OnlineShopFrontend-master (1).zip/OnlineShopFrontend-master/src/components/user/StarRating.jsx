import { useState } from 'react';
import { HStack, IconButton } from '@chakra-ui/react';
import { StarIcon } from '@chakra-ui/icons';

function StarRating({ maxStars = 5, onChange }) {
  const [rating, setRating] = useState(0);

  const handleClick = (value) => {
    setRating(value);
    if (onChange) {
      onChange(value);
    }
  };

  return (
    <HStack spacing={2}>
      {Array(maxStars)
        .fill('')
        .map((_, index) => (
          <IconButton
            key={index}
            icon={<StarIcon />}
            color={index < rating ? 'yellow.400' : 'gray.300'}
            onClick={() => handleClick(index + 1)}
            variant="ghost"
            aria-label={`Rate ${index + 1} stars`}
          />
        ))}
    </HStack>
  );
}

export default StarRating;


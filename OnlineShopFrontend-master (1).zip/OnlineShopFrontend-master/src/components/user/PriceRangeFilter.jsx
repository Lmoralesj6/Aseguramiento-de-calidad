import {
  Box,
  Slider,
  SliderTrack,
  SliderFilledTrack,
  SliderThumb,
  SliderMark,
  Tooltip,
  Text
} from "@chakra-ui/react";
import { useState } from "react";
import { Heading } from '@chakra-ui/react'

const PriceRangeFilter = ({ minPrice, maxPrice, onPriceChange }) => {
  // Validar que minPrice y maxPrice siempre sean números antes de usarlos
  const [slideValue, setSlideValue] = useState(maxPrice);
  const [showTooltip, setShowTooltip] = useState(false)

  const handleChange = (value) => {
    onPriceChange(value);
  };

  return (
    <Box width="100%">
      <Heading
        as='h2'
        size='md'
        textAlign='center'
      >
        Filtrando Productos desde Q0.00 hasta Q{slideValue}.00 quetzales.
      </Heading>
      <br />
      <Slider
        aria-label="price-range"
        value={slideValue}
        min={minPrice}
        max={maxPrice}
        step={10}
        onChangeEnd={handleChange}
        onChange={(value) => setSlideValue(value)}
        onMouseEnter={() => setShowTooltip(true)}
        onMouseLeave={() => setShowTooltip(false)}
      >
        <SliderMark value={minPrice} mt="-10" ml="-2.5" fontSize="md">
          {minPrice}
        </SliderMark>
        <SliderMark value={maxPrice} mt="-10" ml="-2.5" fontSize="md">
          {maxPrice}
        </SliderMark>
        <SliderTrack>
          <SliderFilledTrack />
        </SliderTrack>
        <Tooltip
          hasArrow
          bg='teal.500'
          color='white'
          placement='top'
          isOpen={showTooltip}
          label={`Q.${slideValue}`}
        >
          <SliderThumb boxSize={6} />
        </Tooltip>
      </Slider>
    </Box>
  );
};

export default PriceRangeFilter;


import React, { useState, useEffect } from 'react';
import {
  Box,
  Button,
  FormControl,
  FormLabel,
  Input,
  InputGroup,
  InputLeftElement,
  Textarea,
  VStack,
  useToast,
  useColorModeValue,
} from '@chakra-ui/react';
import { BsPerson } from 'react-icons/bs';
import { MdOutlineEmail, MdPhone } from 'react-icons/md';
import ImageUpload from '../../components/common/ImageUpload';
import { sendQuoteRequest } from '../../services/quoteService';

const QuoteForm = ({ change }) => {
  const emptyForm = { name: '', email: '', phone: '', description: '', image: null };
  const [form, setForm] = useState(emptyForm);
  const [showButton, setShowButton] = useState(false);
  const toast = useToast();

  useEffect(() => {
    if (form.email && form.description && form.name) {
      setShowButton(true);
    } else {
      setShowButton(false);
    }
  }, [form]);

  const handleChange = (event) => {
    const name = event.target.name;
    const value = event.target.value;
    setForm((values) => ({ ...values, [name]: value }));
  };

  const convertImageToBase64 = (image) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(image);
      reader.onload = () => resolve(reader.result);
      reader.onerror = (error) => reject(error);
    });
  };

  const handleImageUpload = async (imageFile) => {
    setForm((values) => ({ ...values, image: imageFile }));
    const base64Image = await convertImageToBase64(imageFile);
    change(base64Image); // Actualiza la vista previa de la imagen
  };

  const enviarForm = async () => {
    if (!form.email || !form.description || !form.name) {
      toast({
        title: 'Error al enviar solicitud',
        description: 'Debe completar los campos del formulario',
        status: 'error',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right',
      });
      return;
    }

    const base64Image = await convertImageToBase64(form.image);
    change(base64Image);
    const response = await sendQuoteRequest({ ...form, image: base64Image });
    console.log(response);
    if (response.status == 200) {
      toast({
        title: 'Solicitud enviada',
        description: 'Su solicitud ha sido enviada correctamente',
        status: 'success',
        duration: 3000,
        isClosable: true,
        position: 'bottom-right',
      });
    }
    setForm(emptyForm);
  };

  return (
    <Box
      bg={useColorModeValue("white", "gray.700")}
      borderRadius="lg"
      p={10}
      color={useColorModeValue("gray.700", "whiteAlpha.900")}
      shadow="base"
      width="30vw"
    >
      <VStack spacing={4}>
        <FormControl isRequired>
          <FormLabel>Nombre Completo</FormLabel>
          <InputGroup>
            <InputLeftElement pointerEvents="none">
              <BsPerson color="gray.800" />
            </InputLeftElement>
            <Input
              type="text"
              name="name"
              value={form.name}
              onChange={handleChange}
              placeholder="Nombre Completo"
            />
          </InputGroup>
        </FormControl>

        <FormControl isRequired>
          <FormLabel>Correo</FormLabel>
          <InputGroup>
            <InputLeftElement pointerEvents="none">
              <MdOutlineEmail color="gray.800" />
            </InputLeftElement>
            <Input
              type="email"
              name="email"
              value={form.email}
              onChange={handleChange}
              placeholder="Correo Electrónico"
            />
          </InputGroup>
        </FormControl>

        <FormControl>
          <FormLabel>Teléfono</FormLabel>
          <InputGroup>
            <InputLeftElement pointerEvents="none">
              <MdPhone color="gray.800" />
            </InputLeftElement>
            <Input
              type="text"
              name="phone"
              value={form.phone}
              onChange={handleChange}
              placeholder="Teléfono"
            />
          </InputGroup>
        </FormControl>

        <FormControl isRequired>
          <FormLabel>Descripción</FormLabel>
          <Textarea
            name="description"
            value={form.description}
            onChange={handleChange}
            placeholder="Describe tu solicitud"
            rows={4}
            resize="none"
          />
        </FormControl>

        <ImageUpload onImageUpload={handleImageUpload} hidden={true} />

        {showButton && (
          <Button
            colorScheme="blue"
            bg="blue.400"
            color="white"
            _hover={{ bg: "blue.500" }}
            width="full"
            onClick={enviarForm}
          >
            Enviar Solicitud
          </Button>
        )}
      </VStack>
    </Box>
  );
};

export default QuoteForm;


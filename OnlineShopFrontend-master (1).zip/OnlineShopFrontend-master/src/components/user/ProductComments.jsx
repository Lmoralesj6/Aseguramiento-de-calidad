
import React, { useEffect } from 'react';
import { Box, Text, Avatar, Stack, Flex, ScaleFade } from '@chakra-ui/react';
import ProductComment from './ProductComment'; // Asegúrate de que este importe está correcto

const ProductComments = ({ currentIndex, comments }) => {
  useEffect(() => {
  }, [comments, currentIndex]);

  if (!comments || comments.length === 0) {
    return <div>Sin comentarios</div>;
  }

  return (
    <div>
      <ScaleFade in={true} key={currentIndex} style={{ transitionDuration: '0.45s' }} initialScale={0.9} >
        <ProductComment comment={comments[currentIndex]} />
      </ScaleFade>
    </div>
  );
};

export default ProductComments;


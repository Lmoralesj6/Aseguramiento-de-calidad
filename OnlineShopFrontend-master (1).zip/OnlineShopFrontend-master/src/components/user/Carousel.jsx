import React, { useState } from 'react';
import { Box, Image, Button, Flex } from '@chakra-ui/react';
import img_s1 from '../../assets/images/home_s1.jpg';



const ImageCarousel = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const prevSlide = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex === 0 ? images.length - 1 : prevIndex - 1
    );
  };

  const nextSlide = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex === images.length - 1 ? 0 : prevIndex + 1
    );
  };

  return (
    <Box position="relative" height='100%' width="100%" overflow="hidden" margin="auto" className='image-carousel'>
      <Image src={img_s1} objectFit='cover' width="100%" />
      <Flex position="absolute" top="50%" width="100%" justifyContent="space-between">
      </Flex>
    </Box>
  );
};

export default ImageCarousel;

